"""Excel + PDF export for Parchi Reader."""
from decimal import Decimal, ROUND_HALF_UP
from reader import compute_row


def r2(x):
    if x is None or (isinstance(x, str) and x.strip() == ''):
        return None
    return float(Decimal(str(x)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP))


COLUMNS = ['S.No', 'Item Name', 'Qty', 'Packet Wt', 'G.Wt (g)', 'Tunch', 'Net Wt (g)',
           'T+W', 'Silver Wt (g)', 'Wastage %', 'Wastage Rs/g', 'Labour Rs',
           'Labour Rs/g', 'Rs/piece', 'Supplier Charge', 'Total Amt (Rs)',
           'Making Charge (Customer)', 'Sell Price (Rs)', 'Flag / Note']


def computed_rows(rows, rate_kg, mult=4.0, mult_pc=None):
    if mult_pc is None:
        mult_pc = mult
    out = []
    for r in rows:
        c = compute_row(dict(r), rate_kg, mult, mult_pc)
        pw = c.get('pkt_wt') or ''
        # Single packet wt as a number; several different wts stay as text.
        pw = num3(pw) if (pw and ',' not in str(pw)) else (pw or None)
        out.append([
            c.get('sno'), c.get('item') or '',
            c.get('qty') if c.get('qty') not in (None, '') else None, pw,
            r2(num3(c.get('gwt'))),
            r2(c.get('tunch')), r2(num3(c.get('net'))), r2(num3(c.get('tw'))),
            r2(c.get('silver')), r2(c.get('w_pct')), r2(c.get('w_rsg')),
            r2(c.get('labour')), r2(c.get('l_rsg')),
            r2(c.get('piece_rate')), c.get('supplier_charge'),
            r2(c.get('total_amt')), c.get('making_disp_str') or r2(c.get('making_disp')), r2(c.get('sell_price')),
            c.get('flag') or '',
        ])
    return out


def num3(v):
    try:
        return round(float(v), 3)
    except (TypeError, ValueError):
        return None


def to_excel(rows, rate_kg, path, source='', mult=4.0, mult_pc=None):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    wb = Workbook()
    ws = wb.active
    ws.title = 'Parchi Bifurcation'
    gold = PatternFill('solid', fgColor='C9A227')
    hdr_font = Font(bold=True, color='FFFFFF')
    thin = Border(*[Side(style='thin', color='999999')] * 4)
    ws.merge_cells('A1:S1')
    ws['A1'] = f'Parchi Bifurcation  |  Silver rate Rs {rate_kg:,}/kg pure' + (f'  |  Source: {source}' if source else '')
    ws['A1'].font = Font(bold=True, size=13)
    ws.merge_cells('A2:S2')
    ws['A2'] = ('Method: Silver Wt = Net x (T+W)/100. Tunch from item name (last number 30-100); '
                'wastage % = (T+W) - tunch; wastage Rs/g = wastage% x pure-silver rate. '
                'Labour: piece-rate (n x rate) else Amount column else Rs/kg rate. '
                'Supplier Charge: Rs/piece for piece-rate items, else wastage Rs/g + labour Rs/g. '
                'Making Charge = Making x supplier rate (per piece or per gram). '
                'Review every row before settling.')
    ws['A2'].alignment = Alignment(wrap_text=True, vertical='top')
    ws.row_dimensions[2].height = 36
    for j, h in enumerate(COLUMNS, 1):
        c = ws.cell(row=3, column=j, value=h)
        c.font = hdr_font
        c.fill = gold
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = thin
    ws.row_dimensions[3].height = 30
    data = computed_rows(rows, rate_kg, mult, mult_pc)
    for i, row in enumerate(data, 4):
        for j, v in enumerate(row, 1):
            c = ws.cell(row=i, column=j, value=v)
            c.border = thin
            c.alignment = Alignment(horizontal='center' if j != 2 and j != 19 else 'left',
                                    vertical='center', wrap_text=True)
        ws.row_dimensions[i].height = 22
    widths = [7, 30, 7, 11, 10, 9, 11, 9, 13, 11, 14, 12, 13, 11, 16, 14, 16, 14, 42]
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=3, column=j).column_letter].width = w
    ws.freeze_panes = 'A4'
    wb.save(path)


def _pdf_safe(s):
    return (s.replace('\u2260', '!=').replace('\u2014', '-').replace('\u2013', '-')
             .replace('\u00d7', 'x').replace('\u00b7', '.'))


def to_pdf(rows, rate_kg, path, source='', mult=4.0, mult_pc=None):
    from fpdf import FPDF
    data = computed_rows(rows, rate_kg, mult, mult_pc)

    class PDF(FPDF):
        def header(self):
            self.set_font('Helvetica', 'B', 13)
            self.cell(0, 8, 'Parchi Bifurcation', new_x='LMARGIN', new_y='NEXT')
            self.set_font('Helvetica', '', 8)
            line = f'Silver rate: Rs {rate_kg:,}/kg pure'
            if source:
                line += f'   |   Source: {source}'
            self.cell(0, 5, line, new_x='LMARGIN', new_y='NEXT')
            self.set_font('Helvetica', 'I', 6.5)
            self.multi_cell(0, 3.2,
                'Silver Wt = Net x (T+W)/100. Tunch from item name; wastage % = (T+W)-tunch; '
                'wastage Rs/g = wastage% x pure rate. Labour: piece-rate else Amount else Rs/kg. '
                'Supplier Charge: Rs/piece for piece-rate items, else wastage + labour Rs/g. '
                'Verify every row before settling.',
                new_x='LMARGIN', new_y='NEXT')
            self.ln(2)

        def footer(self):
            self.set_y(-10)
            self.set_font('Helvetica', 'I', 7)
            self.cell(0, 5, f'Page {self.page_no()}/{{nb}}', align='C')

    pdf = PDF('L', 'mm', 'A4')
    pdf.alias_nb_pages('{nb}')
    pdf.set_auto_page_break(True, 14)
    pdf.add_page()
    widths = [9, 34, 8, 11, 11, 11, 12, 11, 14, 11, 12, 14, 14, 12, 15, 16, 14, 15, 33]
    assert sum(widths) == 277  # 297 - 2x10 margins
    x0 = pdf.get_x()

    pdf_cols = ['S.No', 'Item Name', 'Qty', 'Pkt Wt', 'G.Wt', 'Tunch', 'Net (g)', 'T+W',
                'Silver (g)', 'Wst %', 'Wst Rs/g', 'Labour Rs', 'Lab Rs/g', 'Rs/piece',
                'Supplier Charge', 'Total Amt', 'Making', 'Sell Price', 'Flag / Note']

    def draw_header():
        pdf.set_font('Helvetica', 'B', 7)
        pdf.set_fill_color(201, 162, 39)
        pdf.set_text_color(255, 255, 255)
        y_top = pdf.get_y()
        x = x0
        for w, h in zip(widths, pdf_cols):
            pdf.set_xy(x, y_top)
            pdf.multi_cell(w, 7, h, border=1, align='C', fill=True)
            x += w
        pdf.set_xy(x0, y_top + 7)
        pdf.set_text_color(0, 0, 0)
        pdf.set_font('Helvetica', '', 7)

    draw_header()
    for i, row in enumerate(data):
        if i % 2 == 0:
            pdf.set_fill_color(245, 240, 228)
        else:
            pdf.set_fill_color(255, 255, 255)
        cells = [_pdf_safe(str(v)) if v is not None and v != '' else '' for v in row]
        # measure row height
        h = 5
        for w, txt in zip(widths, cells):
            n = pdf.multi_cell(w, 5, txt, dry_run=True, output='LINES')
            h = max(h, len(n) * 5)
        if pdf.get_y() + h > 190:
            pdf.add_page()
            draw_header()
            pdf.set_fill_color(245, 240, 228) if i % 2 == 0 else pdf.set_fill_color(255, 255, 255)
        y_top = pdf.get_y()
        x = x0
        for w, txt in zip(widths, cells):
            pdf.set_xy(x, y_top)
            align = 'L' if txt and not txt[0].isdigit() and txt[0] != '-' else 'C'
            pdf.multi_cell(w, h, txt, border=1, align=align, fill=True, max_line_height=h)
            x += w
        pdf.set_xy(x0, y_top + h)
    pdf.output(path)


# ------------------------------------------------- gold-diamond
from gold import compute_gold

GOLD_COLUMNS = ['S.No', 'Description', 'G.Wt (g)', 'N.Wt (g)', 'Tunch',
                'Dia Wt', 'Dia Rate', 'Dia Value', 'Stone Wt', 'Stone Rate',
                'Stone Value', 'Making Rs/g', 'Making Value',
                'Billed Amt', 'Calc Total', 'Diff', 'Total Amt (with metal)',
                'Flag / Note']


def gold_computed_rows(rows, rate_kg):
    out = []
    for r in rows:
        c = compute_gold(dict(r), rate_kg / 1000.0)
        out.append([
            c.get('sno'), c.get('item') or '', r2(num3(c.get('gwt'))),
            r2(num3(c.get('nwt'))), r2(c.get('tunch')),
            r2(num3(c.get('dia_wt'))), r2(num3(c.get('dia_rate'))), r2(c.get('dia_val')),
            r2(num3(c.get('st_wt'))), r2(num3(c.get('st_rate'))), r2(c.get('st_val')),
            r2(c.get('making')), r2(c.get('making_val')),
            r2(c.get('billed')), r2(c.get('total')), r2(c.get('diff')),
            r2(c.get('grand_total')),
            c.get('flag') or '',
        ])
    return out


def gold_to_excel(rows, rate_kg, path, source=''):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    wb = Workbook()
    ws = wb.active
    ws.title = 'Gold-Diamond Estimate'
    gold = PatternFill('solid', fgColor='C9A227')
    hdr_font = Font(bold=True, color='FFFFFF')
    thin = Border(*[Side(style='thin', color='999999')] * 4)
    n = len(GOLD_COLUMNS)
    ws.merge_cells(f'A1:{chr(64 + n)}1')
    ws['A1'] = f'Gold-Diamond Estimate Verification  |  Gold rate Rs {rate_kg:,}/kg' + (f'  |  Source: {source}' if source else '')
    ws['A1'].font = Font(bold=True, size=13)
    ws.merge_cells(f'A2:{chr(64 + n)}2')
    ws['A2'] = ('Method: Fine = N.Wt x Tunch/100. Calc Total = Dia Wt x Dia Rate + Stone Wt x Stone Rate + Making Rs/g x N.Wt. '
                'Diff = Billed - Calc (flagged if over Rs 2). Total Amt adds fine-gold value at the gold rate '
                '(or G.Bhav from the bill when mentioned). Verify every row before settling.')
    ws['A2'].alignment = Alignment(wrap_text=True, vertical='top')
    ws.row_dimensions[2].height = 36
    for j, h in enumerate(GOLD_COLUMNS, 1):
        c = ws.cell(row=3, column=j, value=h)
        c.font = hdr_font
        c.fill = gold
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        c.border = thin
    ws.row_dimensions[3].height = 30
    for i, row in enumerate(gold_computed_rows(rows, rate_kg), 4):
        for j, v in enumerate(row, 1):
            c = ws.cell(row=i, column=j, value=v)
            c.border = thin
            c.alignment = Alignment(horizontal='center' if j != 2 and j != n else 'left',
                                    vertical='center', wrap_text=True)
        ws.row_dimensions[i].height = 22
    widths = [7, 26, 10, 10, 9, 9, 10, 12, 10, 10, 12, 11, 13, 12, 12, 10, 15, 40]
    for j, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=3, column=j).column_letter].width = w
    ws.freeze_panes = 'A4'
    wb.save(path)


def gold_to_pdf(rows, rate_kg, path, source=''):
    from fpdf import FPDF
    data = gold_computed_rows(rows, rate_kg)

    class PDF(FPDF):
        def header(self):
            self.set_font('Helvetica', 'B', 13)
            self.cell(0, 8, 'Gold-Diamond Estimate Verification', new_x='LMARGIN', new_y='NEXT')
            self.set_font('Helvetica', '', 8)
            line = f'Gold rate: Rs {rate_kg:,}/kg'
            if source:
                line += f'   |   Source: {source}'
            self.cell(0, 5, line, new_x='LMARGIN', new_y='NEXT')
            self.set_font('Helvetica', 'I', 6.5)
            self.multi_cell(0, 3.2,
                'Fine = N.Wt x Tunch/100. Calc = dia+stone+making vs Billed (Diff flagged over Rs 2). '
                'Total Amt adds fine-gold value at gold rate. Verify every row before settling.',
                new_x='LMARGIN', new_y='NEXT')
            self.ln(2)

        def footer(self):
            self.set_y(-10)
            self.set_font('Helvetica', 'I', 7)
            self.cell(0, 5, f'Page {self.page_no()}/{{nb}}', align='C')

    pdf = PDF('L', 'mm', 'A4')
    pdf.alias_nb_pages('{nb}')
    pdf.set_auto_page_break(True, 14)
    pdf.add_page()
    widths = [9, 30, 11, 11, 10, 10, 12, 14, 10, 12, 14, 11, 14, 14, 14, 11, 15, 55]
    assert sum(widths) == 277
    x0 = pdf.get_x()
    pdf_cols = ['S.No', 'Description', 'G.Wt', 'N.Wt', 'Tunch', 'Dia Wt', 'Dia Rate',
                'Dia Val', 'St Wt', 'St Rate', 'St Val', 'Mk Rs/g', 'Mk Val',
                'Billed', 'Calc', 'Diff', 'Total Amt', 'Flag / Note']

    def draw_header():
        pdf.set_font('Helvetica', 'B', 6.5)
        pdf.set_fill_color(201, 162, 39)
        pdf.set_text_color(255, 255, 255)
        y_top = pdf.get_y()
        x = x0
        for w, h in zip(widths, pdf_cols):
            pdf.set_xy(x, y_top)
            pdf.multi_cell(w, 7, h, border=1, align='C', fill=True)
            x += w
        pdf.set_xy(x0, y_top + 7)
        pdf.set_text_color(0, 0, 0)
        pdf.set_font('Helvetica', '', 6.5)

    draw_header()
    for i, row in enumerate(data):
        pdf.set_fill_color(245, 240, 228) if i % 2 == 0 else pdf.set_fill_color(255, 255, 255)
        cells = [_pdf_safe(str(v)) if v is not None and v != '' else '' for v in row]
        h = 5
        for w, txt in zip(widths, cells):
            n = pdf.multi_cell(w, 5, txt, dry_run=True, output='LINES')
            h = max(h, len(n) * 5)
        if pdf.get_y() + h > 190:
            pdf.add_page()
            draw_header()
            pdf.set_fill_color(245, 240, 228) if i % 2 == 0 else pdf.set_fill_color(255, 255, 255)
        y_top = pdf.get_y()
        x = x0
        for w, txt in zip(widths, cells):
            pdf.set_xy(x, y_top)
            align = 'L' if txt and not txt[0].isdigit() and txt[0] != '-' else 'C'
            pdf.multi_cell(w, h, txt, border=1, align=align, fill=True, max_line_height=h)
            x += w
        pdf.set_xy(x0, y_top + h)
    pdf.output(path)
