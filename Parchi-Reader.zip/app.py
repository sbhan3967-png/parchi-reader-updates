"""Parchi Reader - desktop app. Upload a parchi photo/PDF, verify, export Excel/PDF.
Modes: Silver Parchi (karigar rough estimate) and Gold-Diamond (JDM estimate)."""
import os
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import cv2

from reader import read_image, read_pdf, compute_row, dedupe_rows
from gold import read_gold_image, compute_gold
from cloud import login as cloud_login, signup as cloud_signup, \
    friendly_error as cloud_err, \
    list_parchis as cloud_list, \
    get_rows as cloud_rows, upload_parchi as cloud_upload, CloudError, \
    content_hash as cloud_content_hash, find_duplicates as cloud_dupes
from exporters import (to_excel, to_pdf, gold_to_excel, gold_to_pdf, r2)
import updater

VERSION = '4.5'  # bump this on every release; updater compares against it


def fmt(x, nd=2):
    v = r2(x)
    if v is None:
        return ''
    if nd == 3:
        try:
            return f"{float(x):.3f}"
        except (TypeError, ValueError):
            return ''
    return f"{v:.2f}"


SILVER_HEADERS = ['S.No', 'Item Name', 'Qty', 'Packet Wt', 'G.Wt', 'Tunch', 'Net Wt', 'T+W',
                  'Silver Wt', 'Wst %', 'Wst Rs/g', 'Labour Rs', 'Lab Rs/g', 'Total Rs/g',
                  'Total Amt', 'Making Charge', 'Sell Price', 'Flag / Note', '']
SILVER_WIDTHS = [5, 26, 6, 10, 9, 8, 10, 8, 10, 8, 10, 10, 10, 11, 12, 13, 13, 30, 3]

GOLD_HEADERS = ['S.No', 'Description', 'G.Wt', 'N.Wt', 'Tunch', 'Dia Wt', 'Dia Rate',
                'St Wt', 'St Rate', 'Mk/g', 'Billed', 'Calc', 'Diff',
                'Total Amt', 'Flag / Note', '']
GOLD_WIDTHS = [5, 24, 9, 9, 8, 8, 9, 8, 9, 8, 11, 11, 9, 12, 30, 3]


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f'Parchi Reader v{VERSION}')
        self.geometry('1360x740')
        self.files = []
        self.rows = []
        self.row_widgets = []
        self.reading = False
        self.mode = tk.StringVar(value='silver')
        self.cloud_token = None
        self.cloud_uid = None
        self.cloud_user = None

        # ---- top bar ----
        top = ttk.Frame(self, padding=8)
        top.pack(fill='x')
        ttk.Label(top, text='Mode:').pack(side='left', padx=(2, 2))
        ttk.Radiobutton(top, text='Silver Parchi', variable=self.mode, value='silver',
                        command=self.on_mode_change).pack(side='left')
        ttk.Radiobutton(top, text='Gold-Diamond', variable=self.mode, value='gold',
                        command=self.on_mode_change).pack(side='left', padx=(4, 8))
        ttk.Button(top, text='Add Photos', command=self.add_photos).pack(side='left', padx=2)
        ttk.Button(top, text='Add PDF', command=self.add_pdf).pack(side='left', padx=2)
        ttk.Button(top, text='Read Parchi', command=self.do_read).pack(side='left', padx=8)
        ttk.Button(top, text='Clear All', command=self.clear_all).pack(side='left', padx=2)
        ttk.Button(top, text='Check for Updates',
                   command=lambda: self.check_updates(manual=True)).pack(side='left', padx=8)
        self.rate_label = ttk.Label(top, text='Silver rate Rs/kg:')
        self.rate_label.pack(side='left', padx=(18, 2))
        self.rate_var = tk.StringVar(value='205000')
        rate = ttk.Entry(top, textvariable=self.rate_var, width=12)
        rate.pack(side='left')
        rate.bind('<FocusOut>', lambda e: self.recompute_all())
        rate.bind('<Return>', lambda e: self.recompute_all())
        ttk.Label(top, text='Making x:').pack(side='left', padx=(18, 2))
        self.mult_var = tk.StringVar(value='4')
        me = ttk.Entry(top, textvariable=self.mult_var, width=6)
        me.pack(side='left')
        me.bind('<FocusOut>', lambda e: self.recompute_all())
        me.bind('<Return>', lambda e: self.recompute_all())
        ttk.Label(top, text='Find G.Wt:').pack(side='left', padx=(18, 2))
        self.search_var = tk.StringVar()
        se = ttk.Entry(top, textvariable=self.search_var, width=10)
        se.pack(side='left')
        se.bind('<Return>', lambda e: self.find_gwt())
        ttk.Button(top, text='Find', command=self.find_gwt).pack(side='left', padx=2)
        ttk.Separator(top, orient='vertical').pack(side='left', fill='y', padx=8)
        self.cloud_btn = ttk.Button(top, text='Cloud: Login', command=self.cloud_login_dlg)
        self.cloud_btn.pack(side='left', padx=2)
        ttk.Button(top, text='Upload to Cloud', command=self.cloud_upload).pack(side='left', padx=2)
        ttk.Button(top, text='Download from Cloud', command=self.cloud_download_dlg).pack(side='left', padx=2)
        ttk.Button(top, text='Export Excel', command=self.export_excel).pack(side='right', padx=2)
        ttk.Button(top, text='Export PDF', command=self.export_pdf).pack(side='right', padx=2)
        ttk.Button(top, text='+ Add Row', command=self.add_row).pack(side='right', padx=8)

        # ---- file list ----
        fl = ttk.Frame(self, padding=(8, 0))
        fl.pack(fill='x')
        ttk.Label(fl, text='Files:').pack(side='left')
        self.file_var = tk.StringVar(value='(none)')
        ttk.Label(fl, textvariable=self.file_var, foreground='#555').pack(side='left', padx=6)
        self.tip_var = tk.StringVar()
        ttk.Label(fl, textvariable=self.tip_var, foreground='#777',
                  font=('TkDefaultFont', 8)).pack(side='left', padx=12)

        # ---- table ----
        tf = ttk.Frame(self, padding=8)
        tf.pack(fill='both', expand=True)
        self.canvas = tk.Canvas(tf, highlightthickness=0)
        vbar = ttk.Scrollbar(tf, orient='vertical', command=self.canvas.yview)
        hbar = ttk.Scrollbar(tf, orient='horizontal', command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        vbar.pack(side='right', fill='y')
        hbar.pack(side='bottom', fill='x')
        self.canvas.pack(side='left', fill='both', expand=True)
        self.inner = ttk.Frame(self.canvas)
        self.canvas.create_window((0, 0), window=self.inner, anchor='nw')
        self.inner.bind('<Configure>', lambda e: self.canvas.configure(scrollregion=self.canvas.bbox('all')))

        # Mouse-wheel scrolling anywhere over the table (rows are Entry
        # widgets, which swallow wheel events, so plain canvas bindings
        # never fire). Wheel = vertical, Shift+wheel = horizontal.
        def _wheel(event, horizontal=False):
            try:
                cx, cy = self.canvas.winfo_rootx(), self.canvas.winfo_rooty()
                cw, ch = self.canvas.winfo_width(), self.canvas.winfo_height()
            except tk.TclError:
                return
            if not (cx <= event.x_root <= cx + cw and cy <= event.y_root <= cy + ch):
                return  # pointer is outside the table area
            steps = -int(event.delta / 120) if event.delta else 0
            if horizontal:
                self.canvas.xview_scroll(steps, 'units')
            else:
                self.canvas.yview_scroll(steps, 'units')

        self.bind_all('<MouseWheel>', lambda e: _wheel(e))
        self.bind_all('<Shift-MouseWheel>', lambda e: _wheel(e, horizontal=True))
        self.bind_all('<Button-4>', lambda e: self.canvas.yview_scroll(-1, 'units'))
        self.bind_all('<Button-5>', lambda e: self.canvas.yview_scroll(1, 'units'))

        # ---- status ----
        self.status = tk.StringVar(value='Add a parchi photo or PDF, then click Read Parchi.')
        ttk.Label(self, textvariable=self.status, padding=(8, 4),
                  foreground='#333').pack(fill='x', side='bottom')

        self.headers = SILVER_HEADERS
        self.widths = SILVER_WIDTHS
        self.on_mode_change(silent=True)

    # ---------------- mode ----------------
    def on_mode_change(self, silent=False):
        if self.rows and not silent:
            if not messagebox.askyesno('Parchi Reader',
                                       'Switching mode will clear the current table. Continue?'):
                # revert radio
                self.mode.set('gold' if self.mode.get() == 'silver' else 'silver')
                return
            self.rows = []
            self.files = []
            self.update_file_label()
        if self.mode.get() == 'gold':
            self.headers, self.widths = GOLD_HEADERS, GOLD_WIDTHS
            self.rate_label.config(text='Gold rate Rs/kg:')
            self.tip_var.set('Gold-Diamond: white cells editable. Calc = dia+stone+making vs Billed (Diff flagged); '
                             'Total Amt adds metal value at the gold rate (or G.Bhav from bill).')
        else:
            self.headers, self.widths = SILVER_HEADERS, SILVER_WIDTHS
            self.rate_label.config(text='Silver rate Rs/kg:')
            self.tip_var.set('Silver: white cells editable. Type in Wastage % / Wastage Rs/g / Labour Rs/g to override '
                             '(yellow); clear the cell for auto. Total Amt = metal value + labour (your cost). '
                             'Making Charge = Making x labour; Sell Price = metal value + making charge.')
        self.build_table()

    # ---------------- table ----------------
    def build_table(self):
        for w in self.inner.winfo_children():
            w.destroy()
        for j, h in enumerate(self.headers):
            ttk.Label(self.inner, text=h, font=('TkDefaultFont', 9, 'bold'),
                      background='#C9A227', foreground='white',
                      width=self.widths[j], anchor='center').grid(row=0, column=j, sticky='nsew', padx=1, pady=1)
        self.row_widgets = []
        for i, r in enumerate(self.rows):
            self.make_row(i + 1, r)

    def _entry(self, grid_row, col, field, idx, align='center', width=None):
        e = ttk.Entry(self.inner, width=width or self.widths[col],
                      justify=align)
        v = self.rows[idx].get(field)
        e.insert(0, '' if v in (None, '') else str(v))
        e.grid(row=grid_row, column=col, sticky='nsew', padx=1, pady=1)
        e.bind('<FocusOut>', lambda ev, i=idx, f=field: self.on_edit(i, f))
        e.bind('<Return>', lambda ev, i=idx, f=field: self.on_edit(i, f))
        return e

    def _calc_label(self, grid_row, col):
        lb = ttk.Label(self.inner, width=self.widths[col], anchor='center',
                       background='#eef', relief='flat')
        lb.grid(row=grid_row, column=col, sticky='nsew', padx=1, pady=1)
        return lb

    def make_row(self, grid_row, r):
        idx = grid_row - 1
        w = {'src': {}, 'ovr': {}, 'labels': {}}
        if self.mode.get() == 'gold':
            for field, c, al in [('sno', 0, 'center'), ('item', 1, 'left'),
                                 ('gwt', 2, 'center'), ('nwt', 3, 'center'),
                                 ('tunch', 4, 'center'), ('dia_wt', 5, 'center'),
                                 ('dia_rate', 6, 'center'), ('st_wt', 7, 'center'),
                                 ('st_rate', 8, 'center'), ('making', 9, 'center'),
                                 ('billed', 10, 'center')]:
                w['src'][field] = self._entry(grid_row, c, field, idx, al)
            for c, key in [(11, 'total'), (12, 'diff'), (13, 'grand_total')]:
                w['labels'][key] = self._calc_label(grid_row, c)
            flag_col, del_col = 14, 15
        else:
            for field, c, al in [('sno', 0, 'center'), ('item', 1, 'left'),
                                 ('qty', 2, 'center'), ('pkt_wt', 3, 'center'),
                                 ('gwt', 4, 'center'), ('tunch', 5, 'center'),
                                 ('net', 6, 'center'), ('tw', 7, 'center'),
                                 ('labour', 11, 'center')]:
                w['src'][field] = self._entry(grid_row, c, field, idx, al)
            for field, c in [('w_pct', 9), ('w_rsg', 10), ('l_rsg', 13)]:
                e = ttk.Entry(self.inner, width=self.widths[c], justify='center')
                e.grid(row=grid_row, column=c, sticky='nsew', padx=1, pady=1)
                e.bind('<FocusOut>', lambda ev, i=idx, f=field: self.on_edit(i, f))
                e.bind('<Return>', lambda ev, i=idx, f=field: self.on_edit(i, f))
                w['ovr'][field] = e
            for c, key in [(8, 'silver'), (14, 'total'), (15, 'total_amt'),
                           (16, 'making_cust'), (17, 'sell_price')]:
                w['labels'][key] = self._calc_label(grid_row, c)
            flag_col, del_col = 18, 19
        flag = tk.Text(self.inner, width=self.widths[flag_col], height=2, wrap='word',
                       font=('TkDefaultFont', 8), state='disabled',
                       background='#f5f5f5')
        flag.grid(row=grid_row, column=flag_col, sticky='nsew', padx=1, pady=1)
        ttk.Button(self.inner, text='\u00d7', width=3,
                   command=lambda i=idx: self.del_row(i)).grid(row=grid_row, column=del_col)
        w['flag'] = flag
        self.row_widgets.append(w)
        self.refresh_row(idx)

    def _set_entry(self, e, text):
        if e.get() != text:
            e.delete(0, 'end')
            e.insert(0, text)

    def read_sources(self, idx):
        r = self.rows[idx]
        w = self.row_widgets[idx]
        for field, e in w['src'].items():
            r[field] = e.get().strip()

    def on_edit(self, idx, field):
        if not (0 <= idx < len(self.rows)):
            return
        r = self.rows[idx]
        w = self.row_widgets[idx]
        if field in w['src']:
            r[field] = w['src'][field].get().strip()
            if field == 'labour':
                (r.setdefault('_ov', {})).pop('l_rsg', None)
        elif field in w['ovr']:
            txt = w['ovr'][field].get().strip()
            ov = r.setdefault('_ov', {})
            if txt == '':
                ov.pop(field, None)
            else:
                try:
                    v = float(txt)
                except ValueError:
                    self.status.set(f"Row {r.get('sno')}: '{txt}' is not a number - change ignored.")
                    self.refresh_row(idx)
                    return
                if field == 'w_pct':
                    ov.pop('w_rsg', None)
                    ov['w_pct'] = v
                elif field == 'w_rsg':
                    ov.pop('w_pct', None)
                    ov['w_rsg'] = v
                else:
                    ov['l_rsg'] = v
        self.refresh_row(idx)

    def rate(self):
        try:
            return float(self.rate_var.get().replace(',', ''))
        except ValueError:
            return 205000.0 if self.mode.get() == 'silver' else 1300000.0

    def mult(self):
        # Selling making-charge multiplier (default 4x supplier labour).
        try:
            return float(self.mult_var.get().replace(',', ''))
        except ValueError:
            return 4.0

    def refresh_row(self, idx):
        r = self.rows[idx]
        w = self.row_widgets[idx]
        if self.mode.get() == 'gold':
            c = compute_gold(dict(r), self.rate() / 1000.0)
            w['labels']['total'].config(text=fmt(c.get('total')))
            d = c.get('diff')
            w['labels']['diff'].config(text='' if d is None else fmt(d))
            w['labels']['grand_total'].config(text=fmt(c.get('grand_total')))
        else:
            c = compute_row(dict(r), self.rate(), self.mult())
            ov = r.get('_ov') or {}
            w['labels']['silver'].config(text=fmt(c.get('silver'), 3))
            w['labels']['total'].config(text=fmt(c.get('total')))
            w['labels']['total_amt'].config(text=fmt(c.get('total_amt')))
            w['labels']['making_cust'].config(text=fmt(c.get('making_cust')))
            w['labels']['sell_price'].config(text=fmt(c.get('sell_price')))
            self._set_entry(w['ovr']['w_pct'], fmt(c.get('w_pct')))
            self._set_entry(w['ovr']['w_rsg'], fmt(c.get('w_rsg')))
            self._set_entry(w['ovr']['l_rsg'], fmt(c.get('l_rsg')))
            for f, e in w['ovr'].items():
                e.config(background='#FFF3CD' if f in ov else 'white')
            if 'l_rsg' in ov:
                self._set_entry(w['src']['labour'], fmt(c.get('labour')))
        fl = w['flag']
        fl.config(state='normal')
        fl.delete('1.0', 'end')
        fl.insert('1.0', c.get('flag') or '')
        fl.config(state='disabled')
        r['_computed'] = c

    def recompute_all(self):
        for i in range(len(self.rows)):
            self.read_sources(i)
            self.refresh_row(i)

    def del_row(self, idx):
        if 0 <= idx < len(self.rows):
            del self.rows[idx]
            self.build_table()

    def add_row(self):
        sno = 1
        if self.rows:
            try:
                sno = max(int(str(r.get('sno') or 0)) for r in self.rows) + 1
            except ValueError:
                sno = len(self.rows) + 1
        if self.mode.get() == 'gold':
            self.rows.append({'sno': sno, 'item': '', 'gwt': '', 'nwt': '', 'tunch': '',
                              'dia_wt': '', 'dia_rate': '', 'st_wt': '', 'st_rate': '',
                              'making': '', 'billed': '', 'flag': ''})
        else:
            self.rows.append({'sno': sno, 'item': '', 'gwt': '', 'tunch': '', 'net': '',
                              'tw': '', 'labour': '', 'rtext': '', 'amt_text': '', 'flag': ''})
        self.build_table()

    # ---------------- search ----------------
    def find_gwt(self):
        txt = self.search_var.get().strip().replace(',', '')
        try:
            target = float(txt)
        except ValueError:
            self.status.set('Type a gross weight (e.g. 5.240) in the Find box, then press Find.')
            return
        for i in range(len(self.rows)):
            self.read_sources(i)
        for w in self.row_widgets:
            w['flag'].config(background='#f5f5f5')
        hits = []
        for i, r in enumerate(self.rows):
            try:
                v = float(str(r.get('gwt') or '').strip())
            except (ValueError, TypeError):
                continue
            if abs(v - target) < 0.0005:
                hits.append(i)
        if not hits:
            self.status.set(f'No item with G.Wt {txt} g found.')
            return
        for i in hits:
            self.row_widgets[i]['flag'].config(background='#C8E6C9')
        self.update_idletasks()
        y = self.row_widgets[hits[0]]['src']['sno'].winfo_y()
        h = self.inner.winfo_height()
        if h > 0:
            self.canvas.yview_moveto(max(0.0, (y - 120) / h))
        descs = '; '.join(f"row {self.rows[i].get('sno')}: {self.rows[i].get('item')}" for i in hits[:5])
        more = f' (+{len(hits) - 5} more)' if len(hits) > 5 else ''
        self.status.set(f'Found {len(hits)} item(s) with G.Wt {txt} g -> {descs}{more}')

    # ---------------- files / reading ----------------
    def add_photos(self):
        ps = filedialog.askopenfilenames(title='Select parchi photo(s)',
                                         filetypes=[('Images', '*.jpg *.jpeg *.png *.bmp *.tif *.tiff *.webp')])
        if ps:
            self.files.extend(ps)
            self.update_file_label()

    def add_pdf(self):
        p = filedialog.askopenfilename(title='Select parchi PDF',
                                       filetypes=[('PDF', '*.pdf')])
        if p:
            self.files.append(p)
            self.update_file_label()

    def update_file_label(self):
        self.file_var.set(', '.join(os.path.basename(f) for f in self.files) or '(none)')

    def clear_all(self):
        self.files = []
        self.rows = []
        self.update_file_label()
        self.build_table()
        self.status.set('Cleared. Add a parchi photo or PDF, then click Read Parchi.')

    def do_read(self):
        if self.reading:
            return
        if not self.files:
            messagebox.showinfo('Parchi Reader', 'Add a parchi photo or PDF first.')
            return
        self.reading = True
        self.status.set('Reading... (first run downloads the reading engine, needs internet once)')
        threading.Thread(target=self.read_worker, daemon=True).start()

    # ---------------- auto-update ----------------
    def check_updates(self, manual=False):
        """Check the update channel. Manual=True shows 'up to date' too;
        the automatic startup check stays silent when up to date."""
        def worker():
            result = updater.check_for_update(VERSION)
            self.after(0, self._update_result, result, manual)
        threading.Thread(target=worker, daemon=True).start()

    def _update_result(self, result, manual):
        if result is None:
            if manual:
                messagebox.showinfo('Parchi Reader',
                                    f'You are on the latest version ({VERSION}).')
            return
        latest, url, notes = result
        msg = f'A new version is available: {latest} (you have {VERSION}).'
        if notes:
            msg += f'\n\n{notes}'
        msg += '\n\nUpdate now? The app will download it and restart itself.'
        if not messagebox.askyesno('Parchi Reader - Update available', msg):
            return
        self.status.set(f'Downloading update {latest}...')
        def worker():
            try:
                updater.apply_update(url)
                self.after(0, self._update_done, latest)
            except Exception as ex:  # noqa: BLE001
                self.after(0, self._update_failed, str(ex))
        threading.Thread(target=worker, daemon=True).start()

    def _update_done(self, latest):
        messagebox.showinfo('Parchi Reader',
                            f'Updated to version {latest}. Restarting...')
        updater.restart_app()

    def _update_failed(self, msg):
        self.status.set('Update failed.')
        messagebox.showerror('Parchi Reader',
                             f'Could not install the update:\n{msg}\n\n'
                             'Your current version still works fine.')

    def read_worker(self):
        all_rows = []
        gold_mode = self.mode.get() == 'gold'
        try:
            for fi, f in enumerate(self.files):
                self.after(0, self.status.set, f'Reading {os.path.basename(f)} ({fi + 1}/{len(self.files)})...')
                if f.lower().endswith('.pdf'):
                    pages = read_pdf(f)
                    for pname, arr in pages:
                        rows, _t, _wh = (read_gold_image(arr) if gold_mode else read_image(arr))
                        all_rows.extend(rows)
                else:
                    rows, _t, _wh = (read_gold_image(f) if gold_mode else read_image(f))
                    all_rows.extend(rows)
        except Exception as ex:  # noqa: BLE001
            self.after(0, self.read_failed, str(ex))
            return
        # Merge overlapping photos: same S-number in 2 photos = one row
        all_rows = dedupe_rows(all_rows)
        self.after(0, self.read_done, all_rows)

    def read_failed(self, msg):
        self.reading = False
        self.status.set('Read failed.')
        messagebox.showerror('Parchi Reader', f'Could not read the file(s):\n{msg}')

    def read_done(self, all_rows):
        self.reading = False
        self.rows = all_rows
        self.build_table()
        flagged = sum(1 for r in self.rows if (r.get('_computed') or {}).get('flag'))
        self.status.set(f'Read {len(self.rows)} item(s) from {len(self.files)} file(s). '
                        f'{flagged} row(s) have notes - please verify every row, then export.')

    # ---------------- export ----------------
    def source_name(self):
        return ', '.join(os.path.basename(f) for f in self.files)

    def export_excel(self):
        if not self.rows:
            messagebox.showinfo('Parchi Reader', 'Nothing to export - read a parchi first.')
            return
        self.recompute_all()
        p = filedialog.asksaveasfilename(title='Save Excel', defaultextension='.xlsx',
                                         filetypes=[('Excel', '*.xlsx')])
        if not p:
            return
        if self.mode.get() == 'gold':
            gold_to_excel(self.rows, self.rate(), p, self.source_name())
        else:
            to_excel(self.rows, self.rate(), p, self.source_name(), self.mult())
        self.status.set(f'Saved Excel: {p}')

    def export_pdf(self):
        if not self.rows:
            messagebox.showinfo('Parchi Reader', 'Nothing to export - read a parchi first.')
            return
        self.recompute_all()
        p = filedialog.asksaveasfilename(title='Save PDF', defaultextension='.pdf',
                                         filetypes=[('PDF', '*.pdf')])
        if not p:
            return
        if self.mode.get() == 'gold':
            gold_to_pdf(self.rows, self.rate(), p, self.source_name())
        else:
            to_pdf(self.rows, self.rate(), p, self.source_name(), self.mult())
        self.status.set(f'Saved PDF: {p}')


    # ---------------- cloud sync ----------------
    def cloud_login_dlg(self):
        d = tk.Toplevel(self)
        d.title('Cloud Login / Sign Up')
        d.geometry('320x210')
        d.transient(self)
        ttk.Label(d, text='Email:').pack(pady=(12, 0))
        em = ttk.Entry(d, width=32)
        em.pack()
        ttk.Label(d, text='Password:').pack(pady=(8, 0))
        pw = ttk.Entry(d, width=32, show='*')
        pw.pack()
        msg = tk.StringVar()
        ttk.Label(d, textvariable=msg, foreground='red').pack()

        def go():
            try:
                tok, uid = cloud_login(em.get().strip(), pw.get())
            except CloudError as e:
                msg.set(cloud_err(str(e))[:100])
                return
            except Exception as e:  # noqa: BLE001
                msg.set(cloud_err(f'Login failed: {e}')[:100])
                return
            self.cloud_token = tok
            self.cloud_uid = uid
            self.cloud_user = em.get().strip()
            self.cloud_btn.config(text=f'Cloud: {self.cloud_user[:18]}')
            self.status.set(f'Logged in to cloud as {self.cloud_user}.')
            d.destroy()

        def go_signup():
            try:
                tok, uid = cloud_signup(em.get().strip(), pw.get())
            except CloudError as e:
                msg.set(cloud_err(str(e))[:100])
                return
            except Exception as e:  # noqa: BLE001
                msg.set(cloud_err(f'Sign-up failed: {e}')[:100])
                return
            self.cloud_token = tok
            self.cloud_uid = uid
            self.cloud_user = em.get().strip()
            self.cloud_btn.config(text=f'Cloud: {self.cloud_user[:18]}')
            self.status.set(f'Account created & logged in as {self.cloud_user}.')
            d.destroy()

        btns = ttk.Frame(d)
        btns.pack(pady=10)
        ttk.Button(btns, text='Login', command=go).pack(side='left', padx=4)
        ttk.Button(btns, text='Sign Up', command=go_signup).pack(side='left', padx=4)
        em.focus()

    def _need_cloud(self):
        if not self.cloud_token:
            messagebox.showinfo('Cloud', 'Log in to the cloud first (Cloud: Login button).')
            return False
        return True

    def cloud_upload(self):
        if not self._need_cloud():
            return
        if not self.rows:
            messagebox.showinfo('Cloud', 'Nothing to upload - read a parchi first.')
            return
        self.recompute_all()
        d = tk.Toplevel(self)
        d.title('Upload to Cloud')
        d.geometry('320x260')
        d.transient(self)
        ttk.Label(d, text='Party name:').pack(pady=(12, 0))
        pe = ttk.Entry(d, width=32)
        pe.pack()
        ttk.Label(d, text='Bill no:').pack(pady=(8, 0))
        be = ttk.Entry(d, width=32)
        be.pack()
        ttk.Label(d, text='Bill date (YYYY-MM-DD):').pack(pady=(8, 0))
        de = ttk.Entry(d, width=32)
        de.insert(0, __import__('datetime').date.today().isoformat())
        de.pack()
        msg = tk.StringVar()
        ttk.Label(d, textvariable=msg, foreground='red').pack()

        def go():
            party = pe.get().strip()
            if not party:
                msg.set('Enter party name.')
                return
            billno = be.get().strip() or None
            chash = cloud_content_hash(self.rows, self.mode.get())
            try:
                dupes = cloud_dupes(self.cloud_token, party, billno, chash)
            except CloudError as e:
                msg.set(str(e)[:90])
                return
            if dupes:
                lines = []
                for p in dupes[:5]:
                    why = ('same bill no' if p.get('match') == 'bill'
                           else 'same items & amounts')
                    lines.append(f"\u2022 {p.get('party_name')} | bill {p.get('bill_no') or '-'} "
                                 f"| {p.get('bill_date') or ''} ({why})")
                if not messagebox.askyesno(
                        'Possible duplicate',
                        'This parchi looks like one already uploaded:\n\n'
                        + '\n'.join(lines)
                        + '\n\nUpload anyway?'):
                    return
            total = sum((r.get('_computed') or {}).get('total_amt') or 0 for r in self.rows)
            try:
                pid = cloud_upload(self.cloud_token, {
                    'user_id': getattr(self, 'cloud_uid', None),
                    'party_name': party,
                    'bill_no': billno,
                    'bill_date': de.get().strip() or None,
                    'kind': self.mode.get(),
                    'metal_rate': self.rate(),
                    'total_amt': round(total, 2),
                    'content_hash': chash,
                }, self.rows)
            except CloudError as e:
                msg.set(str(e)[:90])
                return
            except Exception as e:  # noqa: BLE001
                msg.set(f'Upload failed: {e}'[:90])
                return
            self.status.set(f'Uploaded {len(self.rows)} rows to cloud (parchi {pid[:8]}).')
            d.destroy()

        ttk.Button(d, text='Upload', command=go).pack(pady=10)
        pe.focus()

    def cloud_download_dlg(self):
        if not self._need_cloud():
            return
        try:
            items = cloud_list(self.cloud_token)
        except CloudError as e:
            messagebox.showerror('Cloud', f'Could not list parchis:\n{e}')
            return
        if not items:
            messagebox.showinfo('Cloud', 'No parchis in the cloud yet.')
            return
        d = tk.Toplevel(self)
        d.title('Download from Cloud')
        d.geometry('480x360')
        d.transient(self)
        lb = tk.Listbox(d, font=('TkDefaultFont', 10))
        lb.pack(fill='both', expand=True, padx=8, pady=8)
        for p in items:
            tot = p.get('total_amt')
            lb.insert('end',
                      f"{p.get('party_name')} | {p.get('bill_no') or ''} | {p.get('bill_date') or ''} | "
                      f"{'Gold' if p.get('kind') == 'gold' else 'Silver'} | "
                      f"{'Rs ' + format(tot, ',.0f') if tot else ''}")
        msg = tk.StringVar()
        ttk.Label(d, textvariable=msg, foreground='red').pack()

        def go():
            sel = lb.curselection()
            if not sel:
                msg.set('Select a parchi.')
                return
            p = items[sel[0]]
            try:
                crows = cloud_rows(self.cloud_token, p['id'])
            except CloudError as e:
                msg.set(str(e)[:90])
                return
            # switch mode to match
            kind = p.get('kind') or 'silver'
            if kind != self.mode.get():
                self.mode.set(kind)
                self.on_mode_change(silent=True)
            new_rows = []
            for i, cr in enumerate(crows):
                if kind == 'gold':
                    new_rows.append({
                        'sno': cr.get('sno') or i + 1, 'item': cr.get('item') or '',
                        'gwt': cr.get('gwt'), 'nwt': cr.get('nwt'), 'tunch': cr.get('tunch'),
                        'dia_wt': cr.get('dia_wt'), 'dia_rate': cr.get('dia_rate'),
                        'st_wt': cr.get('st_wt'), 'st_rate': cr.get('st_rate'),
                        'making': cr.get('making'), 'billed': cr.get('billed'), 'flag': cr.get('flag') or '',
                    })
                else:
                    new_rows.append({
                        'sno': cr.get('sno') or i + 1, 'item': cr.get('item') or '',
                        'gwt': cr.get('gwt'), 'tunch': cr.get('tunch'), 'net': cr.get('net'),
                        'tw': cr.get('tw'), 'labour': cr.get('labour_rs'),
                        'rtext': '', 'amt_text': '', 'flag': cr.get('flag') or '',
                    })
            if new_rows and self.rows:
                if not messagebox.askyesno('Download', 'Replace the current table with the downloaded parchi?'):
                    return
            self.rows = new_rows
            self.build_table()
            self.status.set(f"Downloaded '{p.get('party_name')}' ({len(new_rows)} rows) from cloud.")
            d.destroy()

        ttk.Button(d, text='Download Selected', command=go).pack(pady=6)


if __name__ == '__main__':
    app = App()
    # Automatic update check in the background after the window opens.
    # Silent when up to date or offline; prompts only when an update exists.
    app.after(3000, lambda: app.check_updates(manual=False))
    app.mainloop()
