"""Parchi Reader - image preprocessing for phone photos.

Phone photos of parchis are rarely flat, straight, or evenly lit. Running
OCR on the raw photo wastes the engine's accuracy. This module fixes the
photo first, then OCR reads the fixed version:

1. Perspective correction - finds the paper's 4 corners and warps it to a
   flat top-down rectangle (fixes angled/hand-held shots).
2. Enhancement - grayscale, contrast (CLAHE), denoise, 2x upscale, sharpen
   (fixes dim light, small text, blur).

read_image() tries each variant and keeps the best result, so a bad
preprocessing step can never make things worse than the raw photo.
"""
import cv2
import numpy as np


def _order_points(pts):
    """Order 4 corner points: top-left, top-right, bottom-right, bottom-left."""
    rect = np.zeros((4, 2), dtype='float32')
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]  # top-left: smallest x+y
    rect[2] = pts[np.argmax(s)]  # bottom-right: largest x+y
    diff = np.diff(pts, axis=1).ravel()
    rect[1] = pts[np.argmin(diff)]  # top-right: smallest x-y
    rect[3] = pts[np.argmax(diff)]  # bottom-left: largest x-y
    return rect


def correct_perspective(img):
    """Warp the largest paper-like quadrilateral to a flat rectangle.
    Works by thresholding bright paper vs darker background (the common
    hand-held case), then warping the paper's corners to a rectangle.
    Returns the warped image, or None if no clear quadrilateral found."""
    try:
        small = cv2.resize(img, None, fx=0.5, fy=0.5)
        gray = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (5, 5), 0)
        # Paper is brighter than background: Otsu threshold + close gaps
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (15, 15))
        bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, kernel)
        cnts, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            return None
        cnts = sorted(cnts, key=cv2.contourArea, reverse=True)
        img_area = small.shape[0] * small.shape[1]
        paper = None
        for c in cnts:
            area = cv2.contourArea(c)
            # Paper must be a big chunk of the frame, but not the whole frame
            # (if it fills everything, no perspective fix is needed anyway)
            if area < 0.25 * img_area or area > 0.98 * img_area:
                continue
            peri = cv2.arcLength(c, True)
            approx = cv2.approxPolyDP(c, 0.02 * peri, True)
            if len(approx) == 4:
                paper = approx.reshape(4, 2).astype('float32') * 2.0  # back to full res
                break
            # Fallback: use the bounding quadrilateral of the blob
            rect = cv2.minAreaRect(c)
            box = cv2.boxPoints(rect).astype('float32') * 2.0
            paper = box
            break
        if paper is None:
            return None
        rect = _order_points(paper)
        (tl, tr, br, bl) = rect
        width = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
        height = int(max(np.linalg.norm(tr - tl), np.linalg.norm(bl - br)))
        if width < 200 or height < 200:
            return None
        dst = np.array([[0, 0], [width - 1, 0], [width - 1, height - 1], [0, height - 1]],
                       dtype='float32')
        M = cv2.getPerspectiveTransform(rect, dst)
        return cv2.warpPerspective(img, M, (width, height))
    except Exception:
        return None


def enhance(img):
    """Contrast + denoise + upscale + sharpen for small/handwritten text."""
    try:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # CLAHE: local contrast, fixes uneven light/shadow
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        gray = clahe.apply(gray)
        # Denoise (keeps edges)
        gray = cv2.fastNlMeansDenoising(gray, None, 10, 7, 21)
        # 2x upscale for small text
        h, w = gray.shape[:2]
        gray = cv2.resize(gray, (w * 2, h * 2), interpolation=cv2.INTER_CUBIC)
        # Sharpen
        kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
        gray = cv2.filter2D(gray, -1, kernel)
        return cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    except Exception:
        return None


def variants(img):
    """Yield (name, image) variants to try, best first fallback order.
    Always includes the original so preprocessing can never hurt."""
    yield ('original', img)
    enh = enhance(img)
    if enh is not None:
        yield ('enhanced', enh)
    persp = correct_perspective(img)
    if persp is not None:
        yield ('perspective', persp)
        pe = enhance(persp)
        if pe is not None:
            yield ('perspective+enhanced', pe)
