================================================================
 PARCHI READER - parchi bifurcation software
================================================================

WHAT IT DOES
  Upload a photo (or PDF) of a karigar's "Rough Estimate" parchi.
  Two modes (switch at the top-left):

  SILVER PARCHI (e.g. Wazirpur Nitin Ji): reads the table and makes
  the per-item bifurcation in the same format as the Bill-49 sheet:
  G.Wt, tunch, net wt, T+W, silver wt, wastage %, wastage Rs/g,
  labour Rs, labour Rs/g, total making Rs/g and Total Amt
  (metal value + labour).

  GOLD-DIAMOND (e.g. JDM estimate): reads description, G.Wt, N.Wt,
  tunch, diamond wt/rate, stone wt/rate, making Rs/g, billed amount.
  It verifies: Calc = dia wt x dia rate + stone wt x stone rate +
  making x N.Wt, and flags any Diff vs the billed amount. Total Amt
  adds the fine-gold value at the gold rate (or G.Bhav from the bill
  when mentioned).

  You verify every row, then download Excel or PDF.

NEW: FIND BY G.WT
  Type a gross weight (e.g. 5.240) in the "Find G.Wt" box and press
  Find (or Enter). The matching item row(s) light up green and the
  table scrolls to them - handy when the karigar asks "what about
  the 5.240 piece?".

INSTALL (one time, needs internet)
  1. Extract the FULL zip to a folder (e.g. Documents\Parchi-Reader).
     Do not run Setup from inside the zip.
  2. Double-click Setup.bat and wait. If Python is missing it
     installs Python 3.12 by itself (first via winget, else by
     downloading it silently - no admin needed), then installs the
     required packages, downloads the reading engine once, and puts
     a "Parchi Reader" icon on your desktop.
     When it says "Setup complete", close the window.
  3. Double-click the desktop icon to start.
  NOTE: if your antivirus removes/quarantines Setup.bat, open
  Windows Security -> Protection history -> restore it (it only
  downloads Python and installs packages - nothing harmful).

USE
  1. Pick the mode (Silver Parchi / Gold-Diamond) at the top-left.
  2. Set the metal rate (Rs/kg pure) at the top. Default 205000
     (silver). For gold-diamond, type your gold rate.
  3. "Add Photos" (jpg/png) or "Add PDF" - you can add several.
  4. Click "Read Parchi" and wait (about 10-20 seconds per photo).
  5. VERIFY every row.
     SILVER: fix item names, G.Wt, tunch, net wt, T+W, labour.
     The Flag/Note column tells you what needs attention
     (e.g. "Amount 10538 != piece total 5400").
     - S.No, Item, G.Wt, Tunch, Net Wt, T+W, Labour Rs are editable.
     - Wastage %, Wastage Rs/g and Labour Rs/g are ALSO editable:
       type a value to override the machine (the cell turns yellow),
       clear the cell to go back to auto. Overriding Wastage Rs/g
       back-calculates Wastage %; overriding Labour Rs/g
       back-calculates Labour Rs.
     - Silver Wt, Total Rs/g and Total Amt are read-only - they
       always recalculate from everything else, instantly.
     GOLD-DIAMOND: fix description, weights, dia/stone wt+rate,
     making Rs/g, billed amount. Calc/Diff/Total Amt recalculate
     live; rows where Billed != Calc are flagged.
     - "+ Add Row" adds a blank row; the X button deletes a row.
  6. "Export Excel" or "Export PDF" to download the sheet.

----------------------------------------------------------------
HOW THE READING MACHINE WORKS (in simple words)
----------------------------------------------------------------
  1. FINDING THE WORDS (OCR): An AI model trained on printed text
     scans the photo and finds every word/number with its position
     (like you reading each cell, but it notes the exact x-y of
     everything). This runs fully on your computer - the photo never
     goes to any server.

  2. STRAIGHTENING: If the photo is tilted, it measures the tilt from
     the text lines themselves and corrects every word's position,
     so rows line up even on a slightly rotated photo.

  3. FINDING ROWS: Words on the same height are grouped into lines.
     A line that starts with S1/S2/... (or, if the S-number was cut
     off in the photo, a line with an item name + 3 or more numbers)
     starts a new item. Packet-detail lines like (2x3.000=6.000) are
     attached to the item above them.

  4. FINDING COLUMNS: Instead of guessing column positions (photos
     bend and shift), it uses YOUR rule backwards - it tries every
     combination of three numbers until it finds the triple where
     Net x (T+W)/100 = Silver Wt. That triple MUST be Net, T+W and
     Silver. Everything left of Net is G.Wt/Less; the rightmost
     number is the Amount.

  5. YOUR BIFURCATION LOGIC:
     - Tunch = the purity number in the item name (e.g. 92.5 in
       "MURTI 92.5"); if it is bigger than T+W it is a model number
       and tunch is taken as T+W (flagged for you).
     - No number in the name = tunch T+W, wastage 0, labour only.
     - Wastage % = (T+W) - tunch; wastage Rs/g = wastage% x pure rate.
     - Labour = piece-rate (n x rate, e.g. 3x1800) else the Amount
       column else the Rs/kg "Wt" rate x net wt.
     - Total making Rs/g = wastage Rs/g + labour Rs/g.

  6. YOU VERIFY: The machine proposes, you dispose. Anything odd is
     put in the Flag/Note column. Never settle a parchi on the
     machine's reading alone - that is what the verify step is for.

  GOLD-DIAMOND READING (JDM format): rows are anchored on the Amount
  column (rightmost). Columns are found by position: Description,
  G.Wt, N.Wt, Tunch, Diamond Wt/Code/Rate, Stone Wt/Code/Rate,
  Making Rs/g, Fine, Amount. Verification: Fine = N.Wt x Tunch/100;
  Calc Total = Dia Wt x Dia Rate + Stone Wt x Stone Rate +
  Making Rs/g x N.Wt; Diff = Billed - Calc, flagged if over Rs 2.
  Total Amt = Calc + Fine x gold rate (uses G.Bhav from the bill when
  the bill mentions one, else your gold rate from the top bar).

TROUBLESHOOTING
  - App doesn't open: run Parchi-Reader-Debug.bat - it shows the error.
  - "Read" is slow the first time: the reading engine downloads once
    (~15 MB). After that it works offline.
  - Bad reading: retake the photo straight-on, in good light, without
    shadow/hand over the table. PDF scans read best of all.
  - A row is wrong: just edit the cells - totals recalculate instantly.

Made for Aurum Diamonds / Online Munim. Logic validated against
Wazirpur Nitin Ji Bill 49 (19/10/2026): 29 of 30 item totals match
the hand-verified sheet exactly; the last differs by 1 paisa.
