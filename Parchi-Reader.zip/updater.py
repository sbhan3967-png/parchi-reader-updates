"""Parchi Reader - automatic updates for client PCs.

How it works:
1. On startup (background thread, never blocks the UI) the app fetches
   version.json from the update channel (a GitHub repo you control).
2. If version.json has a newer version, the user is asked once:
   "New version X available. Update now?"
3. On Yes: the new Parchi-Reader.zip is downloaded, extracted over the
   install folder, and the app restarts itself on the new version.
   No reinstall, no Setup re-run, no files to copy by hand.

To push an update (for Suraj, from his PC):
1. Build the new Parchi-Reader.zip.
2. Upload it to the parchi-reader-updates repo (browser upload),
   replacing the old zip.
3. Edit version.json in the same repo: bump "version" to the new number.
Every client PC picks it up automatically on next launch.

If there is no internet, or the check fails, the app just runs normally
and tries again next launch. Nothing ever breaks because of an update.
"""
import json
import os
import shutil
import sys
import tempfile
import urllib.request
import zipfile

# Update channel: a GitHub repo Suraj controls. version.json lives here.
UPDATE_CHECK_URL = ('https://raw.githubusercontent.com/sbhan3967-png/'
                    'parchi-reader-updates/main/version.json')
# Fallback: if version.json has no "url", the zip is fetched from here.
UPDATE_ZIP_URL = ('https://raw.githubusercontent.com/sbhan3967-png/'
                  'parchi-reader-updates/main/Parchi-Reader.zip')

TIMEOUT = 8  # seconds; a slow connection must never hang the app


def _ver_tuple(v):
    """'4.1.2' -> (4, 1, 2). Non-numeric parts are ignored."""
    out = []
    for part in str(v).split('.'):
        digits = ''.join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


def check_for_update(current_version):
    """Return (latest_version, download_url, notes) if an update exists,
    else None. Never raises: any failure means 'no update right now'."""
    try:
        req = urllib.request.Request(UPDATE_CHECK_URL,
                                     headers={'User-Agent': 'ParchiReader'})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            info = json.loads(resp.read().decode('utf-8'))
        latest = str(info.get('version', '')).strip()
        if not latest or _ver_tuple(latest) <= _ver_tuple(current_version):
            return None
        url = info.get('url') or UPDATE_ZIP_URL
        return (latest, url, info.get('notes', ''))
    except Exception:
        return None


def install_dir():
    """Folder the app is running from (where app.py lives)."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def apply_update(download_url):
    """Download the zip and extract it over the install folder.
    Returns True on success. Raises on failure (caller shows the error)."""
    tmpdir = tempfile.mkdtemp(prefix='parchi_update_')
    zippath = os.path.join(tmpdir, 'update.zip')
    req = urllib.request.Request(download_url,
                                 headers={'User-Agent': 'ParchiReader'})
    with urllib.request.urlopen(req, timeout=60) as resp, open(zippath, 'wb') as f:
        shutil.copyfileobj(resp, f)
    dest = install_dir()
    with zipfile.ZipFile(zippath) as zf:
        # Safety: reject paths that escape the install folder
        for name in zf.namelist():
            target = os.path.normpath(os.path.join(dest, name))
            if not target.startswith(os.path.normpath(dest) + os.sep):
                raise ValueError(f'Unsafe path in update: {name}')
        zf.extractall(dest)
    shutil.rmtree(tmpdir, ignore_errors=True)
    return True


def restart_app():
    """Relaunch the app (via its .bat launcher if present) and exit."""
    import subprocess
    dest = install_dir()
    bat = os.path.join(dest, 'Parchi-Reader.bat')
    if os.path.exists(bat):
        subprocess.Popen([bat], cwd=dest, shell=True)
    else:
        subprocess.Popen([sys.executable, os.path.join(dest, 'app.py')], cwd=dest)
    os._exit(0)
