"""Parchi Reader - Supabase cloud sync. Links the desktop software with the
phone PWA: upload a verified parchi to the cloud, or download one made on
the phone. Uses the Supabase REST API (no extra dependencies)."""
import hashlib
import json
import urllib.request
import urllib.error

SUPABASE_URL = 'https://hywxbogfppjcezvvqtnm.supabase.co'
SUPABASE_ANON_KEY = 'sb_publishable_tdr_ah_JqB2IFQ89p7ua1g_I5MxP-e0'


class CloudError(Exception):
    pass


def _req(method, path, token=None, data=None, params=''):
    url = SUPABASE_URL + path + params
    headers = {
        'apikey': SUPABASE_ANON_KEY,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
    }
    if token:
        headers['Authorization'] = f'Bearer {token}'
    body = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(url, data=body, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            txt = r.read().decode()
            return json.loads(txt) if txt.strip() else None
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode()[:300]
        except Exception:
            detail = ''
        raise CloudError(f'{e.code}: {detail}')


def login(email, password):
    """Returns (access_token, user_id). Raises CloudError on failure."""
    d = _req('POST', '/auth/v1/token?grant_type=password',
             data={'email': email, 'password': password})
    token = d.get('access_token')
    uid = (d.get('user') or {}).get('id')
    if not token:
        raise CloudError('Login failed (no token returned).')
    return token, uid


def signup(email, password):
    """Create a new account. Returns (access_token, user_id).
    Email confirmation is OFF on this project, so the account is usable
    immediately. Raises CloudError on failure (e.g. email already used)."""
    d = _req('POST', '/auth/v1/signup',
             data={'email': email, 'password': password})
    token = d.get('access_token')
    uid = (d.get('user') or {}).get('id')
    if not token:
        # Account created but needs confirmation (should not happen with
        # confirmation OFF) - tell the user to log in instead.
        if uid:
            raise CloudError('Account created. Please log in now.')
        raise CloudError('Sign-up failed (no token returned).')
    return token, uid


def list_parchis(token):
    rows = _req('GET', '/rest/v1/parchis',
                token=token,
                params='?select=id,party_name,bill_no,bill_date,kind,total_amt,created_at&order=created_at.desc&limit=100')
    return rows or []


def get_rows(token, parchi_id):
    rows = _req('GET', '/rest/v1/parchi_rows',
                token=token,
                params=f'?parchi_id=eq.{parchi_id}&select=*&order=sno')
    return rows or []


def upload_parchi(token, meta, rows):
    """meta: {party_name, bill_no, bill_date, kind, metal_rate, total_amt,
              photo_hash, content_hash}.
    rows: list of row dicts (silver or gold fields). Returns parchi id."""
    ins = _req('POST', '/rest/v1/parchis', token=token, data={
        'user_id': meta.get('user_id'),
        'party_name': meta.get('party_name'),
        'bill_no': meta.get('bill_no'),
        'bill_date': meta.get('bill_date'),
        'kind': meta.get('kind', 'silver'),
        'metal_rate': meta.get('metal_rate'),
        'total_amt': meta.get('total_amt'),
        'photo_hash': meta.get('photo_hash'),
        'content_hash': meta.get('content_hash'),
    }, params='?select=id')
    pid = (ins or [{}])[0].get('id')
    if not pid:
        raise CloudError('Upload failed (no parchi id returned).')
    payload = []
    for i, r in enumerate(rows):
        c = r.get('_computed') or {}
        base = {
            'parchi_id': pid, 'sno': r.get('sno') or i + 1,
            'item': r.get('item'), 'gwt': _num(r.get('gwt')),
            'flag': c.get('flag'),
        }
        if (meta.get('kind') == 'gold'):
            base.update({
                'nwt': _num(r.get('nwt')), 'tunch': _num(r.get('tunch')),
                'dia_wt': _num(r.get('dia_wt')), 'dia_rate': _num(r.get('dia_rate')),
                'st_wt': _num(r.get('st_wt')), 'st_rate': _num(r.get('st_rate')),
                'making': _num(r.get('making')), 'billed': _num(r.get('billed')),
                'calc_total': c.get('total'), 'diff': c.get('diff'),
                'total_amt': c.get('grand_total'),
            })
        else:
            base.update({
                'tunch': c.get('tunch'), 'net': _num(r.get('net')), 'tw': _num(r.get('tw')),
                'silver_wt': c.get('silver'), 'wastage_pct': c.get('w_pct'),
                'wastage_rsg': c.get('w_rsg'), 'labour_rs': c.get('labour'),
                'labour_rsg': c.get('l_rsg'), 'total_rsg': c.get('total'),
                'total_amt': c.get('total_amt'),
            })
        payload.append(base)
    if payload:
        _req('POST', '/rest/v1/parchi_rows', token=token, data=payload)
    return pid


def _num(v):
    try:
        return float(v) if v not in (None, '') else None
    except (TypeError, ValueError):
        return None


def content_hash(rows, kind):
    """Stable fingerprint of a parchi's content. Two uploads of the same
    parchi produce the same hash even if bill no/party were typed slightly
    differently. Normalizes numbers to 3 decimals and lowercases item text."""
    parts = []
    for r in rows:
        c = r.get('_computed') or {}
        if kind == 'gold':
            parts.append('|'.join([
                str(r.get('item') or '').strip().lower(),
                _f3(r.get('gwt')), _f3(r.get('nwt')), _f3(r.get('tunch')),
                _f3(r.get('dia_wt')), _f3(r.get('dia_rate')),
                _f3(r.get('st_wt')), _f3(r.get('st_rate')),
                _f3(r.get('making')), _f3(r.get('billed')),
            ]))
        else:
            parts.append('|'.join([
                str(r.get('item') or '').strip().lower(),
                _f3(r.get('gwt')), _f3(r.get('tunch')),
                _f3(r.get('net')), _f3(r.get('tw')),
                _f3(r.get('labour')),
                _f3(c.get('w_pct')), _f3(c.get('l_rsg')),
            ]))
    parts.sort()
    return hashlib.sha256('\n'.join(parts).encode()).hexdigest()[:32]


def _f3(v):
    try:
        return f'{float(v):.3f}'
    except (TypeError, ValueError):
        return ''


def photo_hash_bytes(data: bytes):
    return hashlib.sha256(data).hexdigest()[:32]


def find_duplicates(token, party_name=None, bill_no=None, content_hash=None):
    """Returns list of existing parchis that look like duplicates.
    Each entry: {id, party_name, bill_no, bill_date, kind, match: 'bill'|'content'}."""
    dupes = []
    seen = set()
    if party_name and bill_no:
        q = (f"?select=id,party_name,bill_no,bill_date,kind,created_at"
             f"&party_name=ilike.{party_name.strip()}"
             f"&bill_no=eq.{bill_no.strip()}")
        for p in _req('GET', '/rest/v1/parchis', token=token, params=q) or []:
            p['match'] = 'bill'
            dupes.append(p)
            seen.add(p['id'])
    if content_hash:
        q = (f"?select=id,party_name,bill_no,bill_date,kind,created_at"
             f"&content_hash=eq.{content_hash}")
        for p in _req('GET', '/rest/v1/parchis', token=token, params=q) or []:
            if p['id'] not in seen:
                p['match'] = 'content'
                dupes.append(p)
    return dupes
