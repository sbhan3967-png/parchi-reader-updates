@echo off
cd /d "%~dp0"
echo Starting Parchi Reader in debug mode - if it crashes, the error will show below.
echo.
where python >nul 2>nul
if %errorlevel%==0 (
    python app.py
) else (
    py -3 app.py
)
echo.
echo App closed. If you saw an error above, share a screenshot.
pause
