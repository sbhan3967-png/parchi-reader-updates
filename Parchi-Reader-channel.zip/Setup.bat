@echo off
setlocal
title Parchi Reader - Setup
echo ============================================
echo   Parchi Reader - one-time setup
echo ============================================
echo.

cd /d "%~dp0"

if not exist app.py (
    echo ERROR: app.py not found. Please extract the FULL zip before running Setup.
    pause
    exit /b 1
)

set PY=
rem 1. Direct known install locations (works even if Python is not on PATH)
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles(x86)%\Python312\python.exe"
    "C:\Python312\python.exe"
    "C:\Python313\python.exe"
) do (
    if not defined PY if exist %%P set PY="%%P"
)
rem 2. Try the Python launcher (most reliable on Windows)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY (
    rem 'where' alone is not enough: the Microsoft Store stub also matches.
    Only accept python if it actually runs.
    python --version >nul 2>nul
    if %errorlevel%==0 set PY=python
)
if not defined PY (
    echo Python not found - installing Python 3.12 ^(needs internet^)...
    echo.
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 goto :trypyorg
    echo Python installed via winget.
    goto :findpy
)
goto :pyok

:trypyorg
echo Winget failed - downloading Python directly from python.org...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\parchi-python-setup.exe'"
if errorlevel 1 goto :nopython
echo Installing Python 3.12 silently ^(no admin needed^)...
"%TEMP%\parchi-python-setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
del "%TEMP%\parchi-python-setup.exe" >nul 2>&1
if errorlevel 1 goto :nopython
echo Python installed.
goto :findpy

:findpy
rem winget/silent install does not refresh PATH in this window; pick up the new install directly
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "C:\Program Files\Python312\python.exe") do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY (
    echo.
    echo Python was installed but this window cannot see it yet.
    echo Please CLOSE this window, open the folder again and run Setup again.
    pause
    exit /b 1
)

:pyok
%PY% --version
if errorlevel 1 goto :nopython
echo.
rem --- Version gate: Parchi Reader needs Python 3.12 or 3.13. On a new
rem laptop the newest Python (3.14+) is often the only one installed, and
rem pip cannot resolve the reading-engine packages under it at all
rem (ResolutionImpossible) even though the same install works on 3.12.
rem If the Python found is too new, install 3.12 alongside it and use that.
for /f "tokens=2 delims= " %%V in ('%PY% --version 2^>^&1') do set PYVER=%%V
echo Found Python %PYVER%
echo %PYVER% | findstr /b /c:"3.12." /c:"3.13." >nul
if %errorlevel%==0 goto :pyversok
goto :need312

:need312
if defined TRIED312 goto :nopython312
set TRIED312=1
echo.
echo Python %PYVER% is too new for the reading engine - installing Python 3.12 alongside it ^(your existing Python stays untouched^)...
winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
goto :find312

:dl312
echo Winget failed - downloading Python 3.12 directly from python.org...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\parchi-python-setup.exe'"
if errorlevel 1 goto :nopython312
echo Installing Python 3.12 silently ^(no admin needed^)...
"%TEMP%\parchi-python-setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
del "%TEMP%\parchi-python-setup.exe" >nul 2>&1
if errorlevel 1 goto :nopython312
echo Python 3.12 installed.
goto :find312

:find312
set PY=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "C:\Python312\python.exe"
) do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3.12 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3.12
)
if not defined PY (
    if not defined DL312TRIED (
        set DL312TRIED=1
        goto :dl312
    )
    goto :nopython312
)
goto :pyok

:nopython312
echo.
echo ERROR: Python 3.12 could not be installed automatically.
echo Please install Python 3.12 from https://www.python.org/downloads/
echo ^(tick "Add python.exe to PATH" during install^), then run Setup again.
pause
exit /b 1

:pyversok
echo Using Python %PYVER%
echo.

echo [1/3] Installing required packages ^(one-time, needs internet^)...
%PY% -m pip install --upgrade pip >nul 2>&1
%PY% -m pip install rapidocr_onnxruntime openpyxl fpdf2 PyMuPDF pillow
if %errorlevel%==0 goto :pipok
echo.
echo Combined install failed - retrying one package at a time...
%PY% -m pip install rapidocr_onnxruntime
if errorlevel 1 goto :pipfail
%PY% -m pip install openpyxl fpdf2 PyMuPDF pillow
if errorlevel 1 goto :pipfail
goto :pipok

:pipfail
echo.
echo ERROR: package install failed on Python %PYVER%.
echo Check internet and run Setup again. If it keeps failing, make sure
echo Setup is using Python 3.12 or 3.13 (shown above as "Using Python").
pause
exit /b 1

:pipok
echo.

echo [2/3] Downloading the reading engine ^(one-time, ~15 MB^)...
%PY% -c "from rapidocr_onnxruntime import RapidOCR; RapidOCR(); print('reading engine ready')"
if errorlevel 1 (
    echo WARNING: engine download failed - it will download on first Read instead.
)
echo.

echo [3/3] Creating desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut([IO.Path]::Combine($ws.SpecialFolders('Desktop'), 'Parchi Reader.lnk')); $sc.TargetPath = '%~dp0Parchi-Reader.bat'; $sc.WorkingDirectory = '%~dp0'; $sc.IconLocation = '%~dp0icon.ico'; $sc.Save()"
echo.
echo ============================================
echo   Setup complete! Double-click the
echo   "Parchi Reader" icon on your desktop.
echo ============================================
pause
exit /b 0

:nopython
echo.
echo ERROR: Python could not be installed automatically.
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo ^(tick "Add python.exe to PATH" during install^), then run Setup again.
pause
exit /b 1
