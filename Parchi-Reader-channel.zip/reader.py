"""Parchi Reader core: OCR + tilt fix + table parse + bifurcation logic."""
import re
import math
import numpy as np

# ---------------------------------------------------------------- OCR
_engine = None


def get_engine():
    global _engine
    if _engine is None:
        from rapidocr_onnxruntime import RapidOCR
        _engine = _make_engine()
    return _engine


def _pick_models(base):
    """First complete PP-OCRv6 model trio present in models/, best
    first: full small, then small detector + tiny recognizer (the
    update-channel build: fits GitHub's 25 MB upload limit), then
    full tiny. Returns (det, rec, keys) or None."""
    trios = [('v6_det_small.onnx', 'v6_rec_small.onnx', 'v6_dict_small.txt'),
             ('v6_det_small.onnx', 'v6_rec_tiny.onnx', 'v6_dict_tiny.txt'),
             ('v6_det_tiny.onnx', 'v6_rec_tiny.onnx', 'v6_dict_tiny.txt')]
    import os
    for det_n, rec_n, keys_n in trios:
        det = os.path.join(base, 'models', det_n)
        rec = os.path.join(base, 'models', rec_n)
        keys = os.path.join(base, 'models', keys_n)
        if os.path.exists(det) and os.path.exists(rec) and os.path.exists(keys):
            return det, rec, keys
    return None


def _make_engine():
    """Best available offline engine: PP-OCRv6 models shipped in
    models/ when present (see _pick_models), else the pip package's
    default (v4). Benchmarked on Bill 49 (Oct 2026): full small
    matches v4 on clean photos and fixes S13 labour on a degraded
    photo (5400 vs v4's 2587.5). The channel build (small detector
    + tiny recognizer, user-approved Oct 2026) matches small on
    clean photos but may misread very poor photos (degraded S13
    labour drops to 0). Any failure here falls back to the default
    engine, never a crash."""
    from rapidocr_onnxruntime import RapidOCR
    import os
    base = os.path.dirname(os.path.abspath(__file__))
    trio = _pick_models(base)
    if trio is not None:
        det, rec, keys = trio
        try:
            from rapidocr_onnxruntime.main import DEFAULT_CFG_PATH
            cfg_text = open(DEFAULT_CFG_PATH, encoding='utf-8').read()
            cfg_text = cfg_text.replace(
                'models/ch_PP-OCRv4_det_infer.onnx', det.replace('\\', '/'))
            cfg_text = cfg_text.replace(
                'models/ch_PP-OCRv4_rec_infer.onnx', rec.replace('\\', '/'))
            cfg_text = cfg_text.replace(
                '    rec_img_shape: [3, 48, 320]',
                '    rec_img_shape: [3, 48, 320]\n'
                '    rec_keys_path: ' + keys.replace('\\', '/'))
            import tempfile
            cfg_path = os.path.join(tempfile.gettempdir(),
                                    'parchi_reader_ocr.yaml')
            with open(cfg_path, 'w', encoding='utf-8') as f:
                f.write(cfg_text)
            return RapidOCR(config_path=cfg_path)
        except Exception:
            pass
    return RapidOCR()


def ocr_words(img_bgr):
    """Return list of dicts: t, c (0-100), x0,y0,x1,y1, xc, yc.
    RapidOCR returns a list of [4-point box, text, score]."""
    eng = get_engine()
    result, _ = eng(img_bgr)
    words = []
    if result:
        for entry in result:
            box, txt, sc = entry[0], entry[1], entry[2]
            if not txt or not txt.strip():
                continue
            xs = [p[0] for p in box]
            ys = [p[1] for p in box]
            x0, x1, y0, y1 = min(xs), max(xs), min(ys), max(ys)
            words.append(dict(t=txt.strip(), c=float(sc) * 100,
                              x0=x0, y0=y0, x1=x1, y1=y1,
                              xc=(x0 + x1) / 2, yc=(y0 + y1) / 2))
    return words


# ------------------------------------------------- tilt estimation
def estimate_tilt(words, W, H):
    """Projection-profile search: the rotation giving the peakiest y-histogram."""
    if len(words) < 20:
        return 0.0
    pts = np.array([(w['xc'], w['yc']) for w in words])
    best_a, best_s = 0.0, -1.0
    for a in np.arange(-4.0, 4.01, 0.5):
        t = math.radians(a)
        ys = (pts[:, 1] - H / 2) * math.cos(t) - (pts[:, 0] - W / 2) * math.sin(t)
        hist, _ = np.histogram(ys, bins=max(10, int(H / 8)))
        s = float(np.var(hist))
        if s > best_s:
            best_s, best_a = s, a
    return best_a


# ------------------------------------------------- helpers
def clean_num(t):
    t = t.replace(',', '.').replace(':', '.').replace('/', '.')
    t = re.sub(r'[^0-9.]', '', t)
    t = re.sub(r'\.+', '.', t)
    return t


def is_num(t):
    return bool(re.match(r'^\d+\.\d+$', clean_num(t)))


ZONES = {'gwt': (0.28, 0.375), 'less': (0.375, 0.46), 'net': (0.46, 0.56),
         'tw': (0.56, 0.62), 'labour': (0.62, 0.70), 'silver': (0.70, 0.83),
         'amount': (0.83, 1.01)}


# ---------------- header-aware format intelligence (v4.17) ----------------
# A bill's own header row says what each column means - far more reliable
# than fixed x-zones or loose keywords. L.Wt. IS Less, Tunch is purity,
# Wstg is wastage, a Gold column means plain gold, Diamond/Stone columns
# mean gold-diamond, a Fine column with Lbr (and no Silver/Gold column)
# means silver. When no header row is found (continuation pages), callers
# fall back to the legacy zones / keyword detection.
HEADER_ROLE = {
    'GWT': 'gwt', 'GRWT': 'gwt',
    'LWT': 'less', 'LESS': 'less',
    'NETWT': 'net', 'NWT': 'net',
    'TUNCH': 'tunch', 'TW': 'tw',
    'WSTG': 'wstg',
    'LABOUR': 'labour', 'LBR': 'labour',
    'SILVER': 'silver', 'GOLD': 'gold', 'FINE': 'fine',
    'AMOUNT': 'amount',
    'DIAMOND': 'diamond', 'STONE': 'stone',
    'MAKING': 'making', 'PURITY': 'purity',
    'PCS': 'pcs', 'PC': 'pcs',
    'DESCRIPTION': 'item', 'ITEMNAME': 'item', 'ITEM': 'item',
    'SR': 'item', 'SNO': 'item',
}


def header_key(text):
    return re.sub(r'[^A-Z0-9+]', '', text.upper())


def detect_header_map(words, W, H):
    """Find the header row (y-band with the most known labels) and map
    each role to its x-range (midpoint boundaries between header centres).
    Returns (roles, type_hint) where roles maps role -> (x0_frac, x1_frac)
    and type_hint is 'gold', 'silver' or None. Returns (None, None) when
    no band carries at least 3 known labels (e.g. continuation pages)."""
    bands = []
    for w in sorted(words, key=lambda x: x['yc']):
        role = HEADER_ROLE.get(header_key(w['t']))
        if role is None:
            continue
        placed = False
        for b in bands:
            if abs(b['yc'] - w['yc']) < H * 0.02:
                b['words'].append((w, role))
                b['yc'] = sum(x['yc'] for x, _ in b['words']) / len(b['words'])
                placed = True
                break
        if not placed:
            bands.append({'yc': w['yc'], 'words': [(w, role)]})
    best = None
    for b in bands:
        roles = {r for _, r in b['words']}
        if best is None or len(roles) > len(best[0]):
            best = (roles, b)
    if best is None or len(best[0]) < 3:
        return None, None, {}
    roles, band = best
    centres = sorted((w['xc'] / W, r) for w, r in band['words'])
    # De-duplicate roles, keeping the first (leftmost) occurrence.
    seen, uniq = set(), []
    for c, r in centres:
        if r not in seen:
            seen.add(r)
            uniq.append((c, r))
    mapping = {}
    centres = {}
    for i, (c, r) in enumerate(uniq):
        x0 = 0.0 if i == 0 else (uniq[i - 1][0] + c) / 2
        x1 = 1.01 if i == len(uniq) - 1 else (c + uniq[i + 1][0]) / 2
        mapping[r] = (x0, x1)
        centres[r] = c
    if 'silver' in mapping:
        hint = 'silver'
    elif 'diamond' in mapping or 'stone' in mapping:
        hint = 'gold'
    elif 'gold' in mapping:
        hint = 'plain-gold'
    elif 'fine' in mapping:
        hint = 'silver'
    else:
        hint = None
    return mapping, hint, centres


def header_bill_type(words, W, H):
    """'gold' / 'plain-gold' / 'silver' from the bill's own headers, or None."""
    _m, hint, _c = detect_header_map(words, W, H)
    return hint



def zone_of(x, W):
    f = x / W
    for k, (a, b) in ZONES.items():
        if a <= f < b:
            return k
    return 'item' if f < 0.28 else 'amount'


def is_labour_token(t):
    """Labour rates/totals, not weights: 300.00Wt, 25000.00WI, {8.00x55.00=440.00)."""
    return bool(re.search(r'W(T|I)?\b', t, re.I) or re.search(r'\d\s*[x\u00d7%]\s*\d', t))


_wref = []


def find_triple(cands, W, positional=True):
    """Find (net, tw, silver) using the invariant silver == net * tw / 100.
    cands: list of (value, xc, conf, word). Returns list of same with word refs.
    Positional mode also requires the columns to sit in order with sane
    gaps (tw right of net, silver right of tw). Value-only mode (positional
    = False) drops the gap sizes but KEEPS the left-to-right order: the
    invariant alone cannot tell net from tw (multiplication commutes:
    300x36 and 36x300 both give 108), so order is the only thing
    stopping a labour rate from becoming the net. It is the retry
    when a photo's tilt/crop shifts the columns so the positional search
    fails, before falling back to zone picks that validate nothing. In
    both modes tw is kept to 20..200 (a labour rate like 300 is not T+W)
    and the three values must come from three different words."""
    global _wref
    _wref = [{'v': v, 'x': x, 'w': w} for v, x, c, w in cands]
    best = None
    for nv, nx, nc, nw in cands:
        if not (0.5 <= nv <= 50000):
            continue
        for tv, tx, tc, tw_w in cands:
            if tw_w is nw:
                continue
            if not (20 <= tv <= 200):
                continue
            dx1 = tx - nx
            if positional:
                if not (W * 0.005 < dx1 < W * 0.15):
                    continue
            elif dx1 <= 0:
                continue
            for sv, sx, sc, sw in cands:
                if sw is nw or sw is tw_w:
                    continue
                dx2 = sx - tx
                if positional:
                    if not (W * 0.03 < dx2 < W * 0.35):
                        continue
                elif dx2 <= 0:
                    continue
                if abs(nv * tv / 100 - sv) > max(0.02, sv * 0.001):
                    continue
                score = nc + tc + sc
                if positional and 0.45 < nx / W < 0.60:
                    score += 0.5
                if best is None or score > best[0]:
                    best = (score, (nv, nx, nc), (tv, tx, tc), (sv, sx, sc))
    if best is None:
        return None
    # re-attach word refs
    out = []
    for v, x, c in best[1:]:
        w = next(d['w'] for d in _wref if abs(d['x'] - x) < 0.01 and abs(d['v'] - v) < 1e-9)
        out.append((v, x, c, w))
    return out


def strip_leading_fragments(item):
    """Drop leading bill-no / phone fragments from an item name.
    Only '#' tokens or long pure-digit runs (5+) are stripped, so real
    name parts like '92.5' survive. Keeps at least one word."""
    words = item.split()
    while len(words) > 1 and re.match(r'^(#|\d{5,}$)', words[0]):
        words.pop(0)
    return ' '.join(words)




def zone_of_mapped(x, W, mapping):
    """Column role for an x position: the bill's own header ranges when
    a header map exists, else the legacy fixed zones. Header roles are
    normalised to the parser's vocabulary (tunch -> tw, gold/fine ->
    silver i.e. the fine-metal column)."""
    if mapping:
        f = x / W
        alias = {'tunch': 'tw', 'gold': 'silver', 'fine': 'silver'}
        for role, (a, b) in mapping.items():
            if a <= f < b:
                return alias.get(role, role)
    return zone_of(x, W)

# ------------------------------------------------- table parse
def parse_words(words, W, H):
    # Drop the parchi's own column-header labels before line grouping:
    # the v6 detector reads the header row reliably, and its words sit
    # close enough to the first data row to merge into it ('Item Name'
    # was landing inside S1's name). These labels are never item words.
    HEADER_WORDS = {'ITEMNAME', 'GWT', 'NETWT', 'NWT', 'LESS', 'T+W',
                    'LABOUR', 'SILVER', 'AMOUNT', 'SNO', 'QTY'}
    # Header map BEFORE the filter below strips header labels: the map
    # needs the header words present to learn the column ranges.
    hmap, _hmap_hint, hcentres = detect_header_map(words, W, H)
    _hspacing = 0.06
    if hcentres:
        _cs = sorted(hcentres.values())
        _diffs = sorted(_cs[i + 1] - _cs[i] for i in range(len(_cs) - 1))
        if _diffs:
            _hspacing = _diffs[len(_diffs) // 2]
    words = [w for w in words
             if re.sub(r'[^A-Z0-9+]', '', w['t'].upper()) not in HEADER_WORDS]
    tilt = estimate_tilt(words, W, H)
    tn = math.tan(math.radians(tilt))
    for w in words:
        w['yc'] = w['yc'] - w['xc'] * tn
    words = sorted(words, key=lambda w: w['yc'])
    TOL = H * 0.014
    rows = []
    for w in words:
        r = next((r for r in rows if abs(r['yc'] - w['yc']) < TOL), None)
        if r is None:
            r = {'yc': w['yc'], 'words': []}
            rows.append(r)
        r['words'].append(w)
        r['yc'] = sum(x['yc'] for x in r['words']) / len(r['words'])
    rows.sort(key=lambda r: r['yc'])
    for r in rows:
        r['words'].sort(key=lambda w: w['x0'])

    SNO_MAX = 50  # bigger "S-numbers" are tunch/model remnants, not serials
    items, cur = [], None
    for r in rows:
        left_w = [w for w in r['words'] if w['xc'] / W < 0.32]
        left_text = ' '.join(w['t'] for w in left_w)
        m = re.search(r'\bS\D{0,2}(\d{1,2})(?!\d)', left_text, re.I)
        sno = int(m.group(1)) if m and int(m.group(1)) <= SNO_MAX else None
        if sno is None:
            mb = re.match(r'(\d{1,2})(?=\s|[A-Z(\uff08])', left_text)
            if mb and int(mb.group(1)) <= SNO_MAX:
                sno = int(mb.group(1))
        nums = [w for w in r['words'] if is_num(w['t'])]
        line_text = ' '.join(w['t'] for w in r['words'])
        is_packet = (('(' in left_text) or ('\uff08' in left_text)) and sno is None
        is_piece = bool(re.search(r'\d\s*[x\u00d7%]\s*\d[\d.]*\s*=', line_text))
        has_alpha = any(re.search(r'[A-Za-z]{2,}', w['t']) for w in left_w)
        cur_nums = sum(1 for rr in (cur['rows'] if cur else [])
                       for w in rr['words'] if is_num(w['t']))
        data_like = len(nums) >= 3 and has_alpha
        cur_complete = cur_nums >= 2
        if sno is not None:
            cur = {'sno': sno, 'rows': [r]}
            items.append(cur)
        elif data_like:
            if cur is None or cur_complete:
                cur = {'sno': 0, 'rows': [r]}
                items.append(cur)
            else:
                cur['rows'].append(r)          # rest of the same item's numbers
        elif cur is None:
            pass                              # ignore stray line
        elif is_piece and abs(r['yc'] - cur['rows'][-1]['yc']) < H * 0.06:
            cur['rows'].append(r)
        elif is_packet or (has_alpha and not nums):
            cur['rows'].append(r)
        elif len(nums) >= 2 and not cur_complete:
            cur['rows'].append(r)
        elif (cur is not None
              and abs(r['yc'] - cur['rows'][-1]['yc']) < H * 0.04
              and not has_alpha and not nums and not is_packet):
            # Bare tunch annotation: a short number like "60" below
            # the item name (e.g. BOMBAY BICHHIYA / 60). It has no
            # alpha, no decimal (so is_num is False), no parens.
            tunch_words = [w for w in left_w
                           if re.match(r'^\d{2,3}$', w['t'].strip())]
            if tunch_words:
                try:
                    tv = int(tunch_words[0]['t'].strip())
                    if 30 <= tv <= 100:
                        cur['rows'].append(r)
                except (ValueError, TypeError):
                    pass
        # else: ignore stray line

    # fill missing S-numbers: backward then forward from known anchors, else sequential
    for i in range(len(items) - 2, -1, -1):
        if items[i]['sno'] == 0 and items[i + 1]['sno'] != 0:
            items[i]['sno'] = items[i + 1]['sno'] - 1
    for i in range(1, len(items)):
        if items[i]['sno'] == 0 and items[i - 1]['sno'] != 0:
            items[i]['sno'] = items[i - 1]['sno'] + 1
    for i, it in enumerate(items):
        if it['sno'] == 0:
            it['sno'] = i + 1

    _FOOT = re.compile(r'^\s*(TOTAL|GRAND|CLOSING|BALANCE|BAL\.)\b', re.I)
    _keep = []
    for it in items:
        _t0 = ' '.join(w['t'] for w in it['rows'][0]['words'])
        if _FOOT.search(_t0) or 'BHAV' in _t0.upper():
            break
        _keep.append(it)
    items = _keep
    out = []
    for it in items:
        allw = [w for r in it['rows'] for w in r['words']]
        numws = [(float(clean_num(w['t'])), w['xc'], w['c'], w['t'])
                 for w in allw if is_num(w['t'])]
        numws = [{'v': float(clean_num(w['t'])), 'x': w['xc'], 'c': w['c'],
                      't': w['t'], 'w': w} for w in allw if is_num(w['t'])]
        triple_cands = [(d['v'], d['x'], d['c'], d['w'])
                        for d in numws if not is_labour_token(d['t'])]
        net = tw = silver = ''
        wstg = ''
        silver_w = None
        gwt = ''
        hit = find_triple(triple_cands, W)
        if not hit:
            # Retry on values alone: on a tilted/cropped photo the
            # columns can sit too far apart for the positional gaps,
            # and the zone fallback below would then assign numbers
            # by screen position with no validation at all (a labour
            # rate has landed in T+W that way). A value-only triple
            # still enforces the invariant and the T+W range.
            hit = find_triple(triple_cands, W, positional=False)
        if hit:
            (nv, nx, _nc, nw), (tv, tx, _tc, _tw2), (sv, sx, _sc, sw) = hit
            net, tw, silver, silver_w = f'{nv:g}', f'{tv:g}', f'{sv:g}', sw
            # G.Wt: rightmost number left of Net with value > net (gross > net);
            # skips tunch-in-name and Less column. Sanity: < 3x net.
            cands = [(d['v'], d['x']) for d in numws
                     if d['x'] < nx - 1 and not is_labour_token(d['t']) and d['v'] > nv]
            cands.sort(key=lambda p: -p[1])
            for v, _x in cands:
                if v < nv * 3:
                    gwt = f'{v:g}'
                    break
            if not gwt and cands:
                # Fallback: Less can be huge (e.g. coin-arts packing) breaking
                # the 3x sanity check. G.Wt is the LEFTMOST weight column,
                # so take the leftmost candidate > net.
                cands.sort(key=lambda p: p[1])
                gwt = f'{cands[0][0]:g}'
        if not net:
            cols = {k: [] for k in list(ZONES) + ['wstg']}
            for d in numws:
                # Labour tokens are never weights, and T+W / net get
                # the same sane ranges as the triple search, so a
                # labour rate can no longer land in T+W through here.
                if is_labour_token(d['t']):
                    continue
                z = zone_of_mapped(d['x'], W, hmap)
                if z in cols:
                    cols[z].append((f"{d['v']:g}", d['c']))

            def pick(k):
                a = cols[k]
                if k == 'tw':
                    a = [x for x in a if 20 <= float(x[0]) <= 200]
                elif k == 'net':
                    a = [x for x in a if 0.5 <= float(x[0]) <= 50000]
                if not a:
                    return ''
                a.sort(key=lambda x: -x[1])
                return a[0][0]

            net, tw, silver = pick('net'), pick('tw'), pick('silver')
            gwt = pick('gwt')
            wstg = pick('wstg')

        item = ' '.join(w['t'] for w in it['rows'][0]['words'] if w['xc'] / W < 0.34)
        item = re.sub(r'^.*?\bS\D{0,2}\d{1,2}(?!\d)\s*', '', item, flags=re.I)
        item = re.sub(r'^\d{1,2}\s+', '', item)
        item = re.sub(r'^S\s+', '', item)  # lone S prefix (row marker without digit)
        item = re.sub(r'[(\uff08].*?[)\uff09]', '', item)
        # prettify glued tokens: AV91PAYAL -> AV 91 PAYAL, BARTAN92.5 -> BARTAN 92.5
        item = re.sub(r'(?<=\d)(?=[A-Za-z])', ' ', item)
        item = re.sub(r'(?<=[A-Za-z])(?=\d)', ' ', item)
        # split glued jewellery words: CASTINGKADA -> CASTING KADA,
        # KOHLAPURITOY -> KOHLAPURI TOY (word may be mid-token or at end)
        for w in ('CASTING', 'KADA', 'PUJA', 'ITEM', 'COIN', 'ARTS', 'BOMBAY',
                  'BICHHIYA', 'CHUDI', 'DANA', 'PATRI', 'NARIAL', 'MURTI',
                  'ANTIQUE', 'FANCY', 'BARTAN', 'TOY', 'SAHU', 'CHHATAR',
                  'KOHLAPURI'):
            item = re.sub(r'(?<=[A-Za-z])' + w + r'(?![A-Za-z])', ' ' + w, item)
            item = re.sub(r'^' + w + r'(?=[A-Z])', w + ' ', item)
        # re-strip row-number prefix now that glued digits are split
        # (e.g. 9NARIAL92.5 -> 9 NARIAL 92.5 -> NARIAL 92.5)
        item = re.sub(r'^.*?\bS\D{0,2}\d{1,2}(?!\d)\s*', '', item, flags=re.I)
        item = re.sub(r'^\d{1,2}\s+', '', item)
        item = re.sub(r'^S\s+', '', item)
        item = re.sub(r'\s+', ' ', item).strip()
        # Drop leading bill-no / phone fragments bleeding into the name
        # (e.g. '#9811109350 SAHU DANA PATRI'). Only '#' tokens or long
        # pure-digit runs (5+) are stripped, so real name parts like
        # '92.5' survive.
        item = strip_leading_fragments(item)
        # Capture tunch annotation from continuation lines: a bare
        # number 30-100 in the item-name zone (e.g. "60" below
        # "BOMBAY BICHHIYA" means the tunch is 60, not T+W 68).
        for sub_r in it['rows'][1:]:
            found_tunch = False
            for w in sub_r['words']:
                if w['xc'] / W >= 0.34:
                    continue
                wt = w['t'].strip()
                if re.match(r'^\d{2,3}(\.\d+)?$', wt):
                    try:
                        v = float(wt)
                        if 30 <= v <= 100 and wt not in item:
                            item = item + ' ' + wt
                            found_tunch = True
                            break
                    except (ValueError, TypeError):
                        pass
            if found_tunch:
                break
        # right-side text (labour patterns live here; packets live left of 0.5W)
        rtext = ' '.join(w['t'] for w in allw if w['xc'] / W > 0.5)
        def _amt_pool(role):
            pool = []
            for w in allw:
                t = w['t'].strip()
                if not re.match(r'^[\d.,]+$', t):
                    continue
                if is_labour_token(t):
                    continue
                if w is silver_w:
                    continue
                if zone_of_mapped(w['xc'], W, hmap) != role:
                    continue
                try:
                    pool.append({'v': float(clean_num(t)), 'x': w['xc']})
                except (TypeError, ValueError):
                    continue
            return pool
        lab_pool = []
        for w in allw:
            t = w['t'].strip()
            if not re.match(r'^[\d.,]+$', t):
                continue
            if zone_of_mapped(w['xc'], W, hmap) != 'labour':
                continue
            try:
                lab_pool.append({'v': float(clean_num(t)), 'x': w['xc']})
            except (TypeError, ValueError):
                continue
        if lab_pool and 'labour' in (hcentres or {}):
            _lcx = hcentres['labour']
            lab_rate = min(lab_pool, key=lambda d: abs(d['x'] - _lcx * W))['v']
        elif lab_pool:
            lab_rate = max(lab_pool, key=lambda d: d['x'])['v']
        else:
            lab_rate = None
        less_val = ''
        if 'less' in (hcentres or {}):
            _lcx = hcentres['less'] * W
            _lp = []
            for w in allw:
                t = w['t'].strip()
                if not re.match(r'^[\d.,]+$', t):
                    continue
                if zone_of_mapped(w['xc'], W, hmap) != 'less':
                    continue
                try:
                    _lp.append((abs(w['xc'] - _lcx), float(clean_num(t))))
                except (TypeError, ValueError):
                    continue
            if _lp:
                less_val = f'{min(_lp)[1]:g}'
        amt_cands = _amt_pool('amount') or _amt_pool('silver')
        if amt_cands and 'amount' in (hcentres or {}) and _amt_pool('amount'):
            _cx = hcentres['amount'] * W
            _near = [d for d in amt_cands if abs(d['x'] - _cx) <= _hspacing * W]
            if _near:
                amt_text = f"{min(_near, key=lambda d: abs(d['x'] - _cx))['v']:g}"
            else:
                # Amount pool exists but nothing sits near the Amount
                # header: this line has no Amount (a far number belongs
                # to a neighbouring sheet, not to this item).
                amt_text = ''
        elif amt_cands:
            amt_text = f"{max(amt_cands, key=lambda d: d['x'])['v']:g}"
        else:
            amt_text = ''
        # Quantity + packet wt from sub-lines: (2x3.000=6.000) -> qty 2,
        # packet wt 3.000. Multiple packet lines: qty sums, packet wt shown
        # once if all equal, else comma-joined. A packet pair is kept only
        # if its product fits the item's Less weight (gwt-net) -- this
        # rejects labour lines like (2x2250=4500) masquerading as packets.
        # Else piece count from piece-rate labour (3x1800 -> qty 3, no
        # packet wt). The lookbehind stops "3.00" being read as count 00.
        sub_text = ' '.join(w['t'] for r in it['rows'][1:] for w in r['words'])
        pairs = [(int(m.group(1)), float(m.group(2))) for m in
                 re.finditer(r'[(\uff08]\s*(?<![\d.])(\d+)\s*[x\u00d7]\s*([\d.]+)',
                             sub_text)]
        _less = None
        try:
            if gwt and net:
                _less = float(gwt) - float(net)
        except (TypeError, ValueError):
            _less = None
        if _less is not None:
            pairs = [p for p in pairs if p[0] * p[1] <= _less + 0.51]
        qty = sum(c for c, _w in pairs) if pairs else ''
        if not qty and 'pcs' in (hcentres or {}):
            _pcx = hcentres['pcs'] * W
            _pcs = []
            for w in allw:
                if not re.match(r'^\d+$', w['t'].strip()):
                    continue
                if abs(w['xc'] - _pcx) > _hspacing * W:
                    continue
                try:
                    _pcs.append((abs(w['xc'] - _pcx), int(w['t'].strip())))
                except (TypeError, ValueError):
                    continue
            if _pcs:
                qty = min(_pcs)[1]
        if pairs:
            wts = sorted({w for _c, w in pairs})
            pkt_wt = f'{wts[0]:.3f}' if len(wts) == 1 else \
                ', '.join(f'{w:.3f}' for w in wts)
        else:
            pkt_wt = ''
            pm = re.search(r'(?<![\d.])(\d+(?:\.\d+)?)\s*[x\u00d7]\s*[\d.]+\s*=',
                           rtext)
            if pm:
                qty = int(float(pm.group(1)))
        out.append({'sno': it['sno'], 'item': item, 'qty': qty, 'pkt_wt': pkt_wt,
                    'gwt': gwt,
                    'net': net, 'tw': tw, 'silver': silver,
                    'wstg': wstg, 'lab_rate': lab_rate, 'less': less_val,
                    'rtext': rtext, 'amt_text': amt_text,
                    'tunch': '', 'labour': '', 'flag': ''})
    return out, tilt


# ------------------------------------------------- business logic
def num(v):
    try:
        n = float(v)
        return n if math.isfinite(n) else None
    except (TypeError, ValueError):
        return None


def infer_tunch(item, tw):
    nums = [float(m.group(1)) for m in re.finditer(r'(\d+(?:\.\d+)?)', item or '')]
    cand = next((v for v in reversed(nums) if 30 <= v <= 100), None)
    if cand is None:
        return tw, ''
    if tw is None:
        return cand, ''
    if cand <= tw:
        return cand, ''
    return tw, 'number in name exceeds T+W \u2014 model no.? tunch taken as T+W'


def piece_rate_match(blob):
    """A piece-rate labour pattern (n x rate = total), e.g. 8x55=440.
    Returns (count, rate, total) or None. The rate is what the
    supplier charges per piece; it is NOT a weight."""
    m = re.search(r'(\d+(?:\.\d+)?)\s*[x\u00d7%]\s*(\d+(?:\.\d+)?)\s*=\s*(\d+(?:\.\d+)?)',
                  blob or '', re.I)
    return (float(m.group(1)), float(m.group(2)), float(m.group(3))) if m else None


def parse_labour(rtext, amt_text, net, tw=None, lab_rate=None):
    blob = (rtext or '') + ' ' + (amt_text or '')
    pm = piece_rate_match(blob)
    amt = num(amt_text)
    wm = re.search(r'(\d+(?:\.\d+)?)\s*WV?(?:T|I)?\b', rtext or '', re.I)
    if pm:
        tot = pm[2]
        flag = ''
        if amt is not None and abs(amt - tot) > max(1, tot * 0.02):
            flag = f'Amount {amt:g} \u2260 piece total {tot:g}'
        return tot, flag, None
    if lab_rate is not None and amt is not None and net:
        metal = net * tw / 100 if tw else net
        if abs(amt - metal * lab_rate) <= max(2, amt * 0.03):
            return 0.0, '', lab_rate
    if wm:
        rate = float(wm.group(1))
        if amt is not None and net:
            # Rate-mode check: Amount == metal x rate means the column
            # holds a per-gram metal rate, not a labour charge (27/06,
            # 5582 formats). Per-kg labour gives Amount == net x rate /
            # 1000, a thousand times smaller, so the two never collide.
            metal = net * tw / 100 if tw else net
            if abs(amt - metal * rate) <= max(2, amt * 0.03):
                return 0.0, '', rate
            return amt, '', None
        if net:
            return rate * net / 1000, '', None
        return 0.0, '', None
    if amt is not None:
        return 0.0, f'Amount {amt:g} ignored (no labour rate on parchi)', None
    return 0.0, '', None


def compute_row(r, rate_kg=205000, mult=4.0, mult_pc=None):
    if mult_pc is None:
        mult_pc = mult
    mult_gm = mult
    rate_g = rate_kg / 1000.0
    net, tw = num(r.get('net')), num(r.get('tw'))
    tunch = num(r.get('tunch'))
    flag = r.get('flag') or ''
    if tunch is None:
        tunch, f2 = infer_tunch(r.get('item') or '', tw)
        if f2:
            flag = (flag + ' | ' + f2) if flag else f2
    if tunch is not None and tunch > 100:
        flag = (flag + ' | ' if flag else '') + 'tunch > 100 impossible \u2014 confirm'
    labour = num(r.get('labour'))
    rate_mode = None
    if labour is None:
        labour, f3, rate_mode = parse_labour(
            r.get('rtext') or '', r.get('amt_text') or '', net, tw,
            num(r.get('lab_rate')))
        if f3:
            flag = (flag + ' | ' + f3) if flag else f3

    # Check piece rate: user input in r['rs_piece'] takes precedence.
    # If explicitly set to empty string '', user cleared piece rate -> treat as gram.
    raw_pr = r.get('rs_piece')
    if raw_pr not in (None, ''):
        piece_rate = num(raw_pr)
    elif raw_pr == '':
        piece_rate = None
    else:
        pm = piece_rate_match((r.get('rtext') or '') + ' ' + (r.get('amt_text') or ''))
        piece_rate = pm[1] if pm else None

    if piece_rate is not None and labour is None:
        qty_val = num(r.get('qty'))
        if qty_val:
            labour = piece_rate * qty_val

    wstg = num(r.get('wstg'))
    # Plain gold (Bill 22): metal uses tunch + wastage, not T+W alone.
    purity_eff = None
    if tunch is not None and wstg is not None:
        purity_eff = tunch + wstg
    elif tw is not None:
        purity_eff = tw
    silver = net * purity_eff / 100 if (net is not None and purity_eff is not None) else None
    if wstg is not None and tunch is not None:
        w_pct = wstg
    elif tw is not None and tunch is not None:
        w_pct = tw - tunch
    else:
        w_pct = None
    if w_pct is not None:
        w_rsg = w_pct / 100 * rate_g
    elif tw is None:
        w_rsg = 0.0  # no T+W on parchi -> labour-only deal
    else:
        w_rsg = None
    l_rsg = labour / net if (labour is not None and net) else None
    # ---- user overrides from the verify table (empty cell = auto) ----
    ov = r.get('_ov') or {}
    if 'w_rsg' in ov:
        w_rsg = ov['w_rsg']
        w_pct = w_rsg / rate_g * 100 if rate_g else None
    elif 'w_pct' in ov:
        w_pct = ov['w_pct']
        w_rsg = w_pct / 100 * rate_g if rate_g else None
    if 'l_rsg' in ov:
        l_rsg = ov['l_rsg']
        if net:
            labour = l_rsg * net
    total = (w_rsg + l_rsg) if (w_rsg is not None and l_rsg is not None) else None
    metal_val = silver * rate_g if silver is not None else None
    total_amt = (metal_val + (labour or 0.0)) if metal_val is not None else None
    # ---- selling side (MRP): the given rate is the PURE rate.
    # Metal = net wt x tunch/100 x pure rate (purity, not T+W —
    # wastage metal is not charged to the customer); customer
    # making:
    # - Per piece: piece_rate x mult_pc (displayed with /pc)
    # - Per gram: total Rs/g x mult_gm (displayed with /gm)
    # Then + 3% GST. Cost side above is unchanged. ----
    typed_tunch = num(r.get('tunch'))
    if typed_tunch is not None:
        tunch_eff = typed_tunch
    elif wstg is not None and tunch is not None:
        tunch_eff = tunch
    elif tw is not None and w_pct is not None:
        tunch_eff = tw - w_pct
    else:
        tunch_eff = tunch
    fine = None
    if net is not None and tunch_eff is not None and tunch_eff >= 0:
        fine = net * tunch_eff / 100
    mrp_metal = fine * rate_g if fine is not None else None

    if piece_rate is not None:
        supplier_charge = f'{piece_rate:g}/pc'
        making_disp = piece_rate * mult_pc
        making_disp_str = f'{making_disp:.2f}/pc'
        making_cust_g = making_disp
    else:
        supplier_charge = f'{total:.2f}/gm' if total is not None else None
        making_cust_g = mult_gm * total if total is not None else None
        making_disp = making_cust_g
        making_disp_str = f'{making_disp:.2f}/gm' if making_disp is not None else ''

    if mrp_metal is not None:
        if piece_rate is not None:
            qty_val = num(r.get('qty'))
            if qty_val is not None and qty_val > 0:
                making_total = making_disp * qty_val
            elif labour is not None:
                making_total = mult_pc * labour
            else:
                making_total = making_disp
        else:
            if making_cust_g is not None and net:
                making_total = making_cust_g * net
            elif labour is not None:
                making_total = mult_gm * labour
            else:
                making_total = 0.0
        sell_price = (mrp_metal + making_total) * 1.03
    else:
        sell_price = None

    _less_raw = num(r.get('less'))
    _gwt_v = num(r.get('gwt'))
    if _less_raw is not None:
        less = _less_raw
    elif _gwt_v is not None and net is not None:
        less = _gwt_v - net
    else:
        less = None
    return dict(r, tunch=tunch_eff, labour=labour, silver=silver, less=less,
                w_pct=w_pct, w_rsg=w_rsg, l_rsg=l_rsg, total=total,
                metal_val=metal_val, total_amt=total_amt,
                fine=fine, mrp_metal=mrp_metal,
                making_cust_g=making_cust_g, sell_price=sell_price, flag=flag,
                piece_rate=piece_rate, supplier_charge=supplier_charge,
                making_disp=making_disp, making_disp_str=making_disp_str)


# ------------------------------------------------- high-level
def _score_rows(rows):
    """Score a parse result for picking the best preprocessing variant.
    Priority: rows with net+tw, then rows where the Silver invariant holds
    (Net x (T+W)/100 = Silver, the strongest sign of a correct parse),
    then total rows. A bad warp can never beat a good parse."""
    valid = 0
    invariant = 0
    for r in rows:
        if r.get('net') and r.get('tw'):
            valid += 1
            try:
                net, tw, sil = float(r['net']), float(r['tw']), float(r.get('silver') or 0)
                if abs(net * tw / 100 - sil) < 0.01:
                    invariant += 1
            except (ValueError, TypeError):
                pass
    return (valid, invariant, len(rows))


def read_image(path_or_array):
    import cv2
    if isinstance(path_or_array, str):
        img = cv2.imread(path_or_array)
    else:
        img = path_or_array
    if img is None:
        return [], 0.0, (0, 0)
    # Try each preprocessing variant, keep the best parse.
    # Original is always tried first so preprocessing can never hurt.
    try:
        import preprocess as _pp
        variant_list = list(_pp.variants(img))
    except Exception:
        variant_list = [('original', img)]
    best_rows, best_tilt, best_wh, best_score = [], 0.0, img.shape[:2][::-1], (-1, -1, -1)
    for _name, vimg in variant_list:
        try:
            H, W = vimg.shape[:2]
            words = ocr_words(vimg)
            rows, tilt = parse_words(words, W, H)
        except Exception:
            continue
        sc = _score_rows(rows)
        if sc > best_score:
            best_rows, best_tilt, best_wh, best_score = rows, tilt, (W, H), sc
        # Early exit: a variant that parsed every row with invariant intact
        if best_score[0] >= 10 and best_score[0] == best_score[1] == best_score[2]:
            break
    # Gap-fill pass: rows missing net or tw get one rescue OCR attempt.
    gap_fill_rows(best_rows, img)
    return best_rows, best_tilt, best_wh


def gap_fill_rows(best_rows, img):
    """Fill missing net/tw from a rescue OCR variant, safely.
    Rescue values are accepted ONLY as a validated net x tw / 100 =
    silver triple, only where they agree with numbers already found,
    and never overwrite a found number. Mutates best_rows in place."""
    gaps = [r for r in best_rows
            if r.get('net') in (None, '') or r.get('tw') in (None, '')]
    if not gaps or img is None:
        return
    try:
        import preprocess as _pp
        rimg = _pp.rescue(img)
        if rimg is None:
            return
        H2, W2 = rimg.shape[:2]
        rrows, _t2 = parse_words(ocr_words(rimg), W2, H2)
    except Exception:
        return
    by_sno = {r.get('sno'): r for r in rrows}
    for r in gaps:
        rr = by_sno.get(r.get('sno'))
        if not rr:
            continue
        try:
            n, t = float(rr['net']), float(rr['tw'])
            s = float(rr.get('silver') or 0)
        except (TypeError, ValueError):
            continue
        if not (n and t and s):
            continue
        if not (20 <= t <= 200):
            continue  # rescue T+W outside the sane range: not T+W
        if abs(n * t / 100 - s) > max(0.02, s * 0.001):
            continue  # rescue triple fails the invariant: reject
        have_net = r.get('net') not in (None, '')
        have_tw = r.get('tw') not in (None, '')
        if have_net and have_tw:
            continue
        try:
            if have_net and abs(float(r['net']) - n) > 0.01:
                continue  # rescue disagrees with the found net
            if have_tw and abs(float(r['tw']) - t) > 0.01:
                continue  # rescue disagrees with the found tw
        except (TypeError, ValueError):
            continue
        if not have_net:
            r['net'] = rr['net']
        if not have_tw:
            r['tw'] = rr['tw']


def dedupe_rows(all_rows):
    """Merge rows from multiple photos of one parchi: same S-number seen in
    overlapping photos must appear once. Keeps the most complete row
    (most filled fields), preferring the first on ties."""
    def completeness(r):
        return sum(1 for k in ('item', 'gwt', 'net', 'tw', 'silver')
                   if r.get(k) not in (None, '', 0))
    by_sno = {}
    order = []
    for r in all_rows:
        sno = r.get('sno')
        if sno is None:
            order.append(r)
            continue
        if sno not in by_sno:
            by_sno[sno] = r
            order.append(r)
        elif completeness(r) > completeness(by_sno[sno]):
            # Replace in place to keep original order
            idx = order.index(by_sno[sno])
            order[idx] = r
            by_sno[sno] = r
    return order


def read_pdf(path, dpi=200):
    """Render each PDF page to an image array (BGR, for cv2/RapidOCR)."""
    import fitz
    doc = fitz.open(path)
    pages = []
    for i, page in enumerate(doc):
        pix = page.get_pixmap(dpi=dpi)
        arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, pix.n)
        if pix.n == 4:
            arr = arr[:, :, :3][:, :, ::-1]  # RGBA -> BGR
        else:
            arr = arr[:, :, ::-1]  # RGB -> BGR
        pages.append((f'page {i + 1}', arr))
    doc.close()
    return pages
