"""Gold-Diamond estimate reader (JDM format): parse + verify logic."""
import re
import math
import numpy as np

from reader import clean_num, is_num, num, estimate_tilt

# column zones as fractions of image width (measured from JDM Bill 3231)
GOLD_ZONES = {
    'desc': (0.00, 0.19), 'purity': (0.19, 0.24), 'gwt': (0.24, 0.29),
    'nwt': (0.29, 0.345), 'tunch': (0.345, 0.39), 'gbhav': (0.39, 0.41),
    'dia_wt': (0.41, 0.47), 'dia_code': (0.47, 0.52), 'dia_rate': (0.52, 0.575),
    'st_wt': (0.575, 0.615), 'st_code': (0.615, 0.665), 'st_rate': (0.665, 0.71),
    'making': (0.71, 0.78), 'fine': (0.78, 0.84), 'amount': (0.84, 1.01),
}


def is_gdec(t):
    return bool(re.match(r'^\d+\.\d+$', clean_num(t)))


def is_gnum(t):
    return bool(re.match(r'^\d+(\.\d+)?$', clean_num(t)))


def gzone_of(x, W):
    f = x / W
    for k, (a, b) in GOLD_ZONES.items():
        if a <= f < b:
            return k
    return 'desc' if f < 0.16 else 'amount'


HEADER_WORDS = {'description', 'purity', 'g.wt', 'n.wt', 'tunch', 'g.bhav',
                'diamond', 'stone', 'wt', 'code', 'rate', 'making', 'fine',
                'amount', 'estimate', 'rupees', '(rupees)'}


def is_header_word(t):
    return t.strip().lower().rstrip('.').strip('()') in HEADER_WORDS


def is_gold_bill(words):
    """Detect if OCR words indicate a Gold-Diamond bill (JDM / Auram Dia / Kamla Nagar)."""
    texts = [w['t'].lower() for w in words]
    count = sum(1 for t in texts if any(k in t for k in [
        '14k', '18k', '14 k', '18 k', 'dia', 'diamond', 'jdm',
        'dnl', 'dto', 'dlr', 'dnp', 'fine', 'kamla nagar', 'auram'
    ]))
    return count >= 4


def parse_gold_words(words, W, H):
    words = [w for w in words if not is_header_word(w['t'])]
    if len(words) < 20:
        return [], 0.0

    # Fine projection-profile tilt search
    pts = np.array([(w['xc'], w['yc']) for w in words])
    best_a, best_s = 0.0, -1.0
    for a in np.arange(-5.0, 5.01, 0.2):
        t = math.radians(a)
        ys = (pts[:, 1] - H / 2) * math.cos(t) - (pts[:, 0] - W / 2) * math.sin(t)
        hist, _ = np.histogram(ys, bins=max(20, int(H / 5)))
        s = float(np.var(hist))
        if s > best_s:
            best_s, best_a = s, a

    tilt = best_a
    tn = math.tan(math.radians(tilt))
    for w in words:
        w['yc_detilt'] = w['yc'] - w['xc'] * tn

    # Anchor rows on the Amount column (rightmost, distinctive)
    # Cutoff at H*0.15 ensures Row 1 is never missed
    aa, ab = GOLD_ZONES['amount']
    anchors = []
    for w in words:
        if aa <= w['xc'] / W < ab and is_gdec(w['t']):
            try:
                v = float(clean_num(w['t']))
            except ValueError:
                continue
            if v >= 50 and w['yc'] > H * 0.15:
                anchors.append(w)

    anchors.sort(key=lambda w: w['yc_detilt'])
    # de-dup anchors closer than half a row pitch
    dedup = []
    for a in anchors:
        if not dedup or abs(a['yc_detilt'] - dedup[-1]['yc_detilt']) > H * 0.006:
            dedup.append(a)
    anchors = dedup

    # Map each word to the closest anchor in de-tilted y
    rows_words = {i: [] for i in range(len(anchors))}
    for w in words:
        if w in anchors:
            continue
        dists = [(i, abs(w['yc_detilt'] - a['yc_detilt'])) for i, a in enumerate(anchors)]
        dists.sort(key=lambda x: x[1])
        best_i, best_d = dists[0]
        if best_d < H * 0.012:
            rows_words[best_i].append(w)

    out = []
    for i, a in enumerate(anchors):
        rwords = rows_words[i]
        cols = {}
        for w in rwords:
            z = gzone_of(w['xc'], W)
            cols.setdefault(z, []).append(w)

        def nums(z, fn):
            return [(float(clean_num(w['t'])), w['c']) for w in cols.get(z, [])
                    if fn(w['t'])]

        def best(z, fn=is_gdec):
            a_nums = nums(z, fn)
            if not a_nums:
                return ''
            a_nums.sort(key=lambda x: -x[1])
            return f'{a_nums[0][0]:g}'

        amt = f'{float(clean_num(a["t"])):g}'
        desc_words = [w['t'] for w in cols.get('desc', [])
                      if re.search(r'[A-Za-z0-9]', w['t'])]
        if not desc_words:
            # Check if description words spilled into purity zone
            desc_words = [w['t'] for w in cols.get('purity', [])
                          if not re.match(r'^(14K|18K|22K|94K)$', w['t'].strip(), re.I)
                          and re.search(r'[A-Za-z0-9]', w['t'])]
        desc = re.sub(r'\s+', ' ', ' '.join(desc_words)).strip()
        if not desc:
            # Fallback so no valid bill row is ever discarded
            desc = f'Item {len(out) + 1}'
        desc = re.sub(r'14K$', '', desc)  # purity glued by OCR
        desc = re.sub(r'(?<=[A-Za-z])(?=\d)', ' ', desc)
        desc = re.sub(r'(?<=\d)(?=[A-Za-z])', ' ', desc)
        desc = re.sub(r'\s+', ' ', desc).strip()
        purity_txt = ' '.join(w['t'] for w in cols.get('purity', []))
        purity = '14K' if '14K' in purity_txt else (purity_txt.strip() or '14K')
        making_txt = ' '.join(w['t'] for w in cols.get('making', []))
        m = re.search(r'(\d+(?:\.\d+)?)', making_txt)
        making_rate = m.group(1) if m else ''
        out.append({
            'sno': len(out) + 1, 'item': desc,
            'purity': purity,
            'gwt': best('gwt'), 'nwt': best('nwt'), 'tunch': best('tunch'),
            'dia_wt': best('dia_wt'),
            'dia_code': ' '.join(w['t'] for w in cols.get('dia_code', [])),
            'dia_rate': best('dia_rate', is_gnum),
            'gbhav': best('gbhav', is_gnum),
            'st_wt': best('st_wt'),
            'st_code': ' '.join(w['t'] for w in cols.get('st_code', [])),
            'st_rate': best('st_rate', is_gnum),
            'making': making_rate, 'billed': amt,
            'flag': '',
        })
    return out, tilt


def compute_gold(r, gold_rate_per_g=None):
    """Verify: total = dia_wt*dia_rate + st_wt*st_rate + making_rate*nwt.
    grand_total adds fine*gold_rate (metal value)."""
    flag = r.get('flag') or ''
    nwt, tunch = num(r.get('nwt')), num(r.get('tunch'))
    dia_wt, dia_rate = num(r.get('dia_wt')), num(r.get('dia_rate'))
    st_wt, st_rate = num(r.get('st_wt')), num(r.get('st_rate'))
    making = num(r.get('making'))
    billed = num(r.get('billed'))
    fine = nwt * tunch / 100 if (nwt is not None and tunch is not None) else None
    dia_val = dia_wt * dia_rate if (dia_wt is not None and dia_rate is not None) else 0.0
    st_val = st_wt * st_rate if (st_wt is not None and st_rate is not None) else 0.0
    making_val = making * nwt if (making is not None and nwt is not None) else None
    total = dia_val + st_val + (making_val or 0.0)
    if making_val is None:
        total = None
    diff = billed - total if (billed is not None and total is not None) else None
    if diff is not None and abs(diff) > 2:
        flag = (flag + ' | ' if flag else '') + f'billed differs by Rs {diff:,.2f}'
    g_rate = num(r.get('gbhav')) or gold_rate_per_g
    metal_val = fine * g_rate if (fine is not None and g_rate) else None
    grand = (metal_val or 0.0) + dia_val + st_val + (making_val or 0.0)
    if metal_val is None or making_val is None:
        grand = None
    return dict(r, fine=fine, dia_val=dia_val, st_val=st_val,
                making_val=making_val, total=total, diff=diff,
                metal_val=metal_val, grand_total=grand, flag=flag)


def read_gold_image(path_or_array):
    import cv2
    from reader import ocr_words
    if isinstance(path_or_array, str):
        img = cv2.imread(path_or_array)
    else:
        img = path_or_array
    H, W = img.shape[:2]
    words = ocr_words(img)
    rows, tilt = parse_gold_words(words, W, H)
    return rows, tilt, (W, H)
